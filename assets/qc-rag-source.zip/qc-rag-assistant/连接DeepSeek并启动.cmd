@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
title DeepSeek RAG Assistant
set "RAG_PY=%~dp0.venv\Scripts\python.exe"
if /i "%~1"=="--self-test" goto self_test
if exist "%RAG_PY%" (
  "%RAG_PY%" "%~dp0connect_deepseek.py"
) else (
  py -3 "%~dp0connect_deepseek.py"
)
if errorlevel 1 pause
exit /b
:self_test
if exist "%RAG_PY%" (
  "%RAG_PY%" "%~dp0connect_deepseek.py" --self-test
) else (
  py -3 "%~dp0connect_deepseek.py" --self-test
)
exit /b
