"""Bounded TXT/Markdown/DOCX parsing with exact extracted-source locations."""
import re
import zipfile
from xml.etree import ElementTree as ET

MISSING = "未提供"


def parse_source(source):
    suffix = source.suffix.lower()
    if source.stat().st_size > 1024 * 1024:
        raise ValueError("单份标准不能超过 1 MB。")
    if suffix in (".txt", ".md"):
        return source.read_text(encoding="utf-8-sig"), "原文行号"
    if suffix == ".docx":
        with zipfile.ZipFile(source) as archive:
            if sum(i.file_size for i in archive.infolist()) > 10 * 1024 * 1024:
                raise ValueError("DOCX 解压后不能超过 10 MB。")
            xml = archive.read("word/document.xml")
        root = ET.fromstring(xml)
        ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
        # Includes table paragraphs in document order; text only, no macros/links executed.
        lines = ["".join(t.text or "" for t in p.findall(".//w:t", ns))
                 for p in root.findall(".//w:body//w:p", ns)]
        return "\n".join(lines), "DOCX 提取段落行号（非页码）"
    raise ValueError("支持 UTF-8 TXT、Markdown 和 DOCX；PDF 请先转为带章节标记的文本。")


def split_clauses(original):
    clauses, active = [], None
    for n, line in enumerate(original.splitlines(), 1):
        heading = re.fullmatch(r"(?:#{1,6}\s+)?\[([A-Za-z0-9_-]+)\]\s*(.+)", line.strip())
        markdown = re.fullmatch(r"#{1,6}\s+(.+)", line.strip())
        if heading or markdown:
            active = {"clause_id": heading[1] if heading else MISSING,
                      "section": heading[2] if heading else markdown[1],
                      "start_line": n, "lines": []}
            clauses.append(active)
        else:
            if active is None and line.strip():
                active = {"clause_id": MISSING, "section": MISSING,
                          "start_line": n, "lines": []}
                clauses.append(active)
            if active is not None:
                active["lines"].append((n, line))
    numbered = [c["clause_id"] for c in clauses if c["clause_id"] != MISSING]
    if len(numbered) != len(set(numbered)):
        raise ValueError("标准中的正式条款编号不能重复。")
    chunks = []
    for index, clause in enumerate(clauses):
        lines = clause.pop("lines")
        # Preamble remains visible in the source viewer; numbered documents retrieve clauses only.
        if numbered and clause["section"] == MISSING:
            continue
        # Split long physical lines while keeping the original physical line number.
        units = [(n, text[i:i+1100]) for n, text in lines
                 for i in range(0, max(1, len(text)), 1100)]
        cursor, part = 0, 0
        while cursor < len(units):
            end, size = cursor, 0
            while end < len(units) and (size + len(units[end][1]) <= 1600 or end == cursor):
                size += len(units[end][1]) + 1
                end += 1
            # Keep original physical-line boundaries: slices of one long line
            # must not acquire synthetic newlines in cited excerpts.
            selected = units[cursor:end]
            text = "".join(("\n" if j and n != selected[j-1][0] else "") + t
                           for j, (n, t) in enumerate(selected)).strip()
            if text:
                part += 1
                chunks.append({**clause, "chunk_id": f"chunk-{index+1}-{part}",
                               "start_line": clause["start_line"] if cursor == 0 else units[cursor][0],
                               "end_line": units[end-1][0], "text": text})
            if end == len(units):
                break
            # One short line overlap; always advances, with provenance unchanged.
            cursor = end-1 if end-cursor > 1 and len(units[end-1][1]) <= 200 else end
    if not chunks:
        raise ValueError("标准没有可检索正文。")
    return chunks
