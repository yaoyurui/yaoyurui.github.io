"""Local standard retrieval and append-only human review records."""
import hashlib
import html
import json
import math
import re
import sqlite3
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from urllib.parse import quote
from standard_parser import MISSING, parse_source, split_clauses


class RuleError(ValueError):
    def __init__(self, message, status=422):
        super().__init__(message)
        self.status = status


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                     separators=(",", ":")).encode("utf-8")).hexdigest()


def terms(value):
    value = value.casefold()
    words = set(re.findall(r"[a-z0-9_]+", value))
    for run in re.findall(r"[\u3400-\u9fff]+", value):
        words.update(run[i:i+2] for i in range(len(run)-1))
    return words


class QualityService:
    def __init__(self, root, data_dir=None):
        self.root = Path(root)
        self.library = self.root / "standards"
        self.data = Path(data_dir) if data_dir else self.root / "data"
        self.data.mkdir(parents=True, exist_ok=True)
        self.db = self.data / "reviews.sqlite3"
        with self.connection() as con:
            con.executescript("""
                CREATE TABLE IF NOT EXISTS comparisons(
                    id TEXT PRIMARY KEY, payload TEXT NOT NULL, created_at TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS reviews(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    comparison_id TEXT NOT NULL, sample_id TEXT NOT NULL,
                    payload TEXT NOT NULL, created_at TEXT NOT NULL);
                CREATE INDEX IF NOT EXISTS review_lookup
                    ON reviews(comparison_id,sample_id,id);
            """)

    @contextmanager
    def connection(self):
        connection = sqlite3.connect(self.db, timeout=10)
        try:
            with connection:
                yield connection
        finally:
            connection.close()

    def documents(self):
        try:
            raw = json.loads((self.library / "catalog.json").read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            raise RuleError("标准库无法读取，请检查 standards/catalog.json。") from exc
        if not isinstance(raw, list) or len(raw) > 100:
            raise RuleError("标准目录应为不超过 100 份文档的数组。")
        documents, ids = [], set()
        for item in raw:
            if not isinstance(item, dict):
                raise RuleError("标准元数据格式不正确。")
            required = ("id", "title", "product", "version", "status", "effective_date", "source_file")
            item = dict(item)
            for field in ("title", "product", "version", "effective_date", "part"):
                item[field] = item.get(field) or MISSING
            item.setdefault("status", "current")
            if any(not isinstance(item.get(k), str) or not item[k].strip() for k in required):
                raise RuleError("每份标准必须包含编号、标题、适用产品、版本、状态、生效日期和来源文件。")
            if not isinstance(item["part"], str) or len(item["part"]) > 120:
                raise RuleError("标准适用部位必须是不超过 120 字的文本。")
            if not re.fullmatch(r"[A-Za-z0-9_-]{1,80}", item["id"]) or item["id"] in ids:
                raise RuleError("标准编号重复或包含不支持的字符。")
            if item["status"] not in ("current", "archived"):
                raise RuleError("标准状态只能是 current 或 archived。")
            if item["effective_date"] != MISSING:
                try:
                    datetime.strptime(item["effective_date"], "%Y-%m-%d")
                except ValueError as exc:
                    raise RuleError("标准生效日期应为 YYYY-MM-DD，缺失时为未提供。") from exc
            source = (self.library / item["source_file"]).resolve()
            if not source.is_relative_to(self.library.resolve()):
                raise RuleError("标准原文必须在 standards 目录内。")
            try:
                original, location_kind = parse_source(source)
                clauses = split_clauses(original)
            except Exception as exc:
                raise RuleError("标准解析失败：" + item["source_file"] + "；请核对文件和格式。") from exc
            document = {k: item[k] for k in required}
            document["part"] = item["part"]
            document["location_kind"] = location_kind
            clause_metadata = item.get("clause_metadata", {})
            if not isinstance(clause_metadata, dict):
                raise RuleError("clause_metadata 必须是对象。")
            for clause in clauses:
                meta = clause_metadata.get(clause["clause_id"], {})
                if not isinstance(meta, dict):
                    raise RuleError("条款元数据必须是对象。")
                for k in ("conflict_key", "rule_value"):
                    clause[k] = str(meta.get(k, ""))[:200]
            document["is_demo"] = item.get("is_demo") is not False
            document["original"] = original
            document["hash"] = digest({"metadata": document, "original": original,
                                       "clause_metadata": clause_metadata})
            document["clauses"] = clauses
            ids.add(item["id"])
            documents.append(document)
        return documents

    def catalog(self):
        documents = self.documents()
        public = [{k: d[k] for k in ("id", "title", "product", "version", "status",
                                    "effective_date", "is_demo", "hash", "part")} for d in documents]
        return {"products": sorted({d["product"] for d in documents if d["product"] != MISSING}),
                "documents": public, "all_demo": bool(documents) and all(d["is_demo"] for d in documents)}

    @staticmethod
    def citation(document, clause):
        return {**{k: document[k] for k in ("id", "title", "product", "version", "status",
                                           "effective_date", "is_demo", "hash", "source_file", "part")},
                "clause_id": clause["clause_id"], "section": clause["section"],
                "chunk_id": clause["chunk_id"], "page": MISSING,
                "conflict_key": clause.get("conflict_key", ""), "rule_value": clause.get("rule_value", ""),
                "excerpt": clause["text"],
                "location": f"{clause['section']}；{document['location_kind']}第 {clause['start_line']}–{clause['end_line']} 行；页码：未提供",
                "source_url": "/rules/source?id=" + quote(document["id"]) +
                              "&hash=" + document["hash"] + "#L" + str(clause["start_line"])}

    def search(self, query, product, include_history=False, version="", part=""):
        if not isinstance(query, str) or not 1 <= len(query.strip()) <= 300:
            raise RuleError("请输入 1–300 字的查询内容。")
        if not isinstance(product, str) or not product.strip():
            raise RuleError("请先选择适用产品，避免引用其他产品标准。")
        if not isinstance(include_history, bool) or not isinstance(version, str):
            raise RuleError("版本筛选格式不正确。")
        if not isinstance(part, str) or len(part) > 120:
            raise RuleError("部位字段格式不正确。")
        query = query.strip()
        product, part = product.strip(), part.strip()
        all_docs = self.documents()
        if product not in {d["product"] for d in all_docs}:
            raise RuleError("标准库中没有该产品，请先补充适用标准。")
        docs = [d for d in all_docs if d["product"] == product
                and (include_history or d["status"] == "current")
                and (not version or d["version"] == version)
                and (not part or d["part"] in (part, MISSING))]
        pool = [(d, c, terms(c["section"] + " " + c["text"])) for d in docs for c in d["clauses"]]
        q = terms(query)
        scored = []
        for document, clause, tokens in pool:
            overlap = q & tokens
            if not overlap:
                continue
            score = sum(math.log(1 + len(pool) / (1 + sum(t in p[2] for p in pool)))
                        for t in overlap)
            for word in ("划痕", "脏污", "异物", "磕碰", "开胶", "偏移", "形变", "反光", "复核"):
                if word in query and word in clause["section"]:
                    score += 3
            if query in clause["section"] + clause["text"]:
                score += 3
            if part and document["part"] == part:
                score += 20
            scored.append((score, document, clause))
        scored.sort(key=lambda row: (-row[0], row[1]["id"], row[2]["clause_id"]))
        hits = [self.citation(d, c) for _, d, c in scored[:6]]
        conflicts = []
        for i, left in enumerate(hits):
            for right in hits[i+1:]:
                if (left["conflict_key"] and left["conflict_key"] == right["conflict_key"]
                        and left["rule_value"] and right["rule_value"]
                        and left["rule_value"] != right["rule_value"]):
                    conflicts.append({"left": left["chunk_id"], "left_doc": left["id"],
                                      "right": right["chunk_id"], "right_doc": right["id"],
                                      "topic": left["conflict_key"],
                                      "message": "同一规则主题存在不同约定，请由标准负责人核对。"})
        return {"query": query, "product": product, "part": part, "results": hits, "conflicts": conflicts,
                "message": "找到相关条款，请核对适用范围后人工判断。" if hits else
                           "未找到该产品与版本范围内的相关条款，请补充标准或转人工确认。",
                "method": "本地条款检索与原文引用，未连接大模型，不自动判断缺陷类别。"}

    def source_html(self, document_id, expected_hash=""):
        document = next((d for d in self.documents() if d["id"] == document_id), None)
        if not document:
            raise RuleError("标准不存在或已从当前标准库移除。", 404)
        if expected_hash and expected_hash != document["hash"]:
            raise RuleError("原文已经更新；请以复核记录保存的摘录为准，重新查询后再引用。", 409)
        esc = html.escape
        lines = "".join('<div id="L' + str(n) + '"><span>' + str(n) + '</span>' +
                        esc(line or " ") + '</div>'
                        for n, line in enumerate(document["original"].splitlines(), 1))
        label = "模拟资料，不用于实际生产判定" if document["is_demo"] else "请由质检人员确认适用范围"
        status = "现行" if document["status"] == "current" else "历史版本，不能直接用于当前确认"
        return ('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>' +
                esc(document["title"]) + '</title><style>body{max-width:980px;margin:35px auto;'
                'padding:0 22px;font:15px/1.9 "Microsoft YaHei",sans-serif;color:#18302e}'
                'p{color:#596e65}.warning{background:#fff2d8;padding:12px}'
                '.source div{white-space:pre-wrap;overflow-wrap:anywhere;padding:3px 0}'
                '.source span{display:inline-block;width:45px;color:#8c9a91;user-select:none}'
                ':target{background:#fff0bb}h1{font-size:24px}</style><h1>' +
                esc(document["title"]) + '</h1><p class="warning">' + esc(label) +
                '</p><p>适用产品：' + esc(document["product"]) + '　版本：' +
                esc(document["version"]) + '　状态：' + status + '　生效日期：' +
                esc(document["effective_date"]) + '</p><p>标准编号：' + esc(document["id"]) +
                '　来源文件：' + esc(document["source_file"]) + '</p><div class="source">' +
                lines + '</div></html>')

    def register(self, result):
        comparison_id = digest({"rows": result["rows"], "demo": result.get("demo", False)})
        result["comparison_id"] = comparison_id
        payload = {k: v for k, v in result.items() if k not in ("csv", "reviews")}
        with self.connection() as con:
            con.execute("INSERT OR IGNORE INTO comparisons VALUES(?,?,?)",
                        (comparison_id, json.dumps(payload, ensure_ascii=False), result["created_at"]))
        return comparison_id

    def comparison(self, comparison_id):
        if not isinstance(comparison_id, str) or not re.fullmatch(r"[a-f0-9]{64}", comparison_id):
            raise RuleError("对比记录编号无效。")
        with self.connection() as con:
            row = con.execute("SELECT payload FROM comparisons WHERE id=?", (comparison_id,)).fetchone()
        if not row:
            raise RuleError("对比记录不存在，请先重新导入或加载演示。", 404)
        return json.loads(row[0])

    def reviews(self, comparison_id):
        self.comparison(comparison_id)
        with self.connection() as con:
            data = con.execute("""
                SELECT r.payload FROM reviews r JOIN
                (SELECT sample_id,MAX(id) AS last_id FROM reviews WHERE comparison_id=?
                 GROUP BY sample_id) latest ON r.id=latest.last_id
            """, (comparison_id,)).fetchall()
        return {r["sample_id"]: r for r in (json.loads(row[0]) for row in data)}

    def history(self, comparison_id, sample_id):
        self.comparison(comparison_id)
        with self.connection() as con:
            rows = con.execute("SELECT payload FROM reviews WHERE comparison_id=? AND sample_id=? "
                               "ORDER BY id DESC LIMIT 10", (comparison_id, sample_id)).fetchall()
        return [json.loads(row[0]) for row in rows]

    def save_review(self, payload):
        comparison_id, sample_id = payload.get("comparison_id"), payload.get("sample_id")
        comparison = self.comparison(comparison_id)
        sample = next((r for r in comparison["rows"] if r["id"] == sample_id), None)
        if sample is None:
            raise RuleError("该样本不属于当前对比记录。")
        values = {}
        for key, limit in (("reviewer", 80), ("product", 120), ("final_label", 100),
                           ("note", 2000), ("query", 300)):
            value = payload.get(key, "")
            if not isinstance(value, str) or len(value) > limit:
                raise RuleError("复核字段内容或长度不正确：" + key)
            values[key] = value.strip()
        if not values["reviewer"]:
            raise RuleError("请填写复核人。")
        state = payload.get("state", "待确认")
        if state not in ("待确认", "已确认"):
            raise RuleError("复核状态无效。")
        if not values["product"] or values["product"] not in self.catalog()["products"]:
            raise RuleError("请选择标准库中适用的产品。")
        selected = payload.get("citations", [])
        if not isinstance(selected, list) or len(selected) > 12:
            raise RuleError("引用条款数量无效。")
        docs = {d["id"]: d for d in self.documents()}
        evidence, seen = [], set()
        for selected_item in selected:
            if not isinstance(selected_item, dict):
                raise RuleError("引用信息无效。")
            document = docs.get(selected_item.get("id"))
            if not document or document["hash"] != selected_item.get("hash"):
                raise RuleError("标准已更新或移除，请重新查询后选择引用。", 409)
            if document["product"] != values["product"]:
                raise RuleError("不能引用其他产品的标准。")
            clause = next((c for c in document["clauses"]
                           if c["clause_id"] == selected_item.get("clause_id") and
                           (not selected_item.get("chunk_id") or c["chunk_id"] == selected_item["chunk_id"])), None)
            if not clause:
                raise RuleError("引用条款不存在。")
            key = (document["id"], clause["chunk_id"])
            if key not in seen:
                evidence.append(self.citation(document, clause))
                seen.add(key)
        if state == "已确认":
            if payload.get("authority_confirmed") is not True:
                raise RuleError("请确认结论由有权限的人员给出；本工具不验证人员身份。")
            if not values["final_label"] or not evidence:
                raise RuleError("已确认记录必须填写最终类别并选择依据条款。")
            if any(e["status"] != "current" for e in evidence):
                raise RuleError("历史条款可留作待确认记录，不能直接作为当前已确认结论的依据。")
            if not comparison.get("demo") and any(e["is_demo"] for e in evidence):
                raise RuleError("真实或未标明模拟的数据不能依据模拟标准保存为已确认，请保持待确认并补充真实标准。")
        record = {**values, "comparison_id": comparison_id, "sample_id": sample_id,
                  "state": state, "authority_confirmed": payload.get("authority_confirmed") is True,
                  "citations": evidence, "sample_snapshot": sample,
                  "created_at": datetime.now().astimezone().isoformat(timespec="seconds")}
        if payload.get("rag_run_id"):
            if not getattr(self, "rag", None):
                raise RuleError("RAG 服务未初始化，请重启助手。")
            run = self.rag.get(payload["rag_run_id"])
            if (run["comparison_id"], run["sample_id"], run["context"]["product"]) != (
                    comparison_id, sample_id, values["product"]):
                raise RuleError("RAG 查询与当前样本或产品不一致，请重新查询。")
            record["rag"] = run
        with self.connection() as con:
            cursor = con.execute("INSERT INTO reviews(comparison_id,sample_id,payload,created_at) VALUES(?,?,?,?)",
                                 (comparison_id, sample_id, json.dumps(record, ensure_ascii=False),
                                  record["created_at"]))
            record["record_id"] = cursor.lastrowid
            con.execute("UPDATE reviews SET payload=? WHERE id=?",
                        (json.dumps(record, ensure_ascii=False), cursor.lastrowid))
        return record
