"""BigModel free-model launcher. No network or inference during startup."""
import getpass
import json
import os
import subprocess
import sys
from pathlib import Path

from connect_deepseek import windows_dialog, normalize_key, key_input_error, free_port

ROOT = Path(__file__).resolve().parent
ENDPOINT = "https://open.bigmodel.cn/api/paas/v4/chat/completions"
MODEL = "glm-4.7-flash"
VERSION = "2026.11.01.bigmodel.5"


def diagnostic(value):
    try:
        target = ROOT / "data" / "bigmodel_connection_diagnostic.json"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    except OSError:
        pass


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    print("智谱 BigModel 免费模型启动向导 — " + VERSION + "\n")
    print("接口：" + ENDPOINT)
    print("固定模型：" + MODEL + "；官方当前列为免费模型，受账号权限及限流约束。")
    print("请在 https://open.bigmodel.cn/ 左侧 API Key 创建模型标准 API 密钥。")
    print("无需购买 Coding Plan，不自动切换其他型号或平台。")
    print("启动时不联网、不验证密钥、不生成文本；记住密钥由 Windows 当前用户加密，明文不写入文件、命令行或网页。\n")
    source = os.environ.pop("RAG_KEY_SOURCE", "input")
    source = source if source in ("saved", "input") else "input"
    value = os.environ.pop("RAG_LAUNCH_KEY", None)
    key = normalize_key(value if value is not None else getpass.getpass("智谱 API Key（隐藏输入）："))
    issue = key_input_error(key)
    if issue:
        diagnostic({"status":"input_rejected", "reason_kind":issue, "network_request_sent":False})
        print("未收到完整密钥，请复制智谱 API Key 的完整值；尚未发送请求。")
        return 1
    port = free_port()
    environment = os.environ.copy()
    environment.update({"RAG_MODEL_URL":ENDPOINT, "RAG_MODEL_NAME":MODEL,
                        "RAG_API_KEY":key, "RAG_JSON_MODE":"1", "RAG_TIMEOUT_SECONDS":"60"})
    environment.pop("RAG_NETWORK_MODE", None)
    diagnostic({"status":"configured_not_verified", "selected_model":MODEL,
                "key_source":source,
                "network_request_sent":False, "authentication_verified":False, "generation_verified":False})
    print("已设置本次后端环境，尚未验证密钥及真实生成能力。")
    print("新页面：http://127.0.0.1:" + str(port) + "/")
    print("加载模拟演示 → SIM-025 → 查询判定依据 → 确认发送并生成建议。")
    print("仅该生成操作会发送当前样本上下文与检索片段到智谱，请先使用模拟资料。")
    print("保持启动窗口打开。\n", flush=True)
    return subprocess.run([sys.executable, str(ROOT / "app.py"), "--open", "--port", str(port)],
                          cwd=ROOT, env=environment).returncode


if __name__ == "__main__":
    try:
        if os.name == "nt" and "--native-input" not in sys.argv:
            raise SystemExit(windows_dialog("--self-test" in sys.argv,
                launcher_file=ROOT / "connect_bigmodel.py", provider="BigModel",
                mode="clear" if "--clear-key" in sys.argv else "change" if "--change-key" in sys.argv else "normal"))
        raise SystemExit(main())
    except (KeyboardInterrupt, EOFError):
        print("\n启动已取消。")
    except OSError:
        print("无法启动，请检查文件完整性和可用端口。")
        raise SystemExit(1)
