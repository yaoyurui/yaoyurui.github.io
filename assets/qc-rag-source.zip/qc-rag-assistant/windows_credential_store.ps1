# .NET ProtectedData calls Windows DPAPI in CurrentUser scope.
# No PowerShell security-module import or execution-policy change is needed.
Add-Type -AssemblyName System.Security
function New-RagSecureString([string]$Value) {
    $ragSecret = [Security.SecureString]::new()
    foreach ($ragCharacter in $Value.ToCharArray()) { $ragSecret.AppendChar($ragCharacter) }
    $ragSecret.MakeReadOnly()
    return $ragSecret
}
function Protect-RagSecret([Security.SecureString]$Secret) {
    $ragBytes = $null
    try {
        $ragBytes = [Text.Encoding]::UTF8.GetBytes((Get-RagPlainKey $Secret))
        $ragEntropy = [Text.Encoding]::UTF8.GetBytes('QC-RAG.BigModel.v1')
        $ragProtected = [Security.Cryptography.ProtectedData]::Protect($ragBytes, $ragEntropy, [Security.Cryptography.DataProtectionScope]::CurrentUser)
        return [Convert]::ToBase64String($ragProtected)
    }
    finally { if ($null -ne $ragBytes) { [Array]::Clear($ragBytes, 0, $ragBytes.Length) } }
}
function Unprotect-RagSecret([string]$Cipher) {
    $ragProtected = [Convert]::FromBase64String($Cipher)
    $ragEntropy = [Text.Encoding]::UTF8.GetBytes('QC-RAG.BigModel.v1')
    $ragBytes = [Security.Cryptography.ProtectedData]::Unprotect($ragProtected, $ragEntropy, [Security.Cryptography.DataProtectionScope]::CurrentUser)
    try { return New-RagSecureString ([Text.Encoding]::UTF8.GetString($ragBytes)) }
    finally { [Array]::Clear($ragBytes, 0, $ragBytes.Length) }
}
function Get-RagCredentialPath([string]$AppRoot) {
    return [IO.Path]::Combine($AppRoot, 'data', 'credentials', 'bigmodel.current-user.dpapi')
}
function Read-RagCredential([string]$AppRoot) {
    $ragPath = Get-RagCredentialPath $AppRoot
    if (-not [IO.File]::Exists($ragPath)) { return $null }
    try {
        if (([IO.FileInfo]::new($ragPath)).Length -gt 131072) { throw 'Invalid size' }
        $ragCipher = [IO.File]::ReadAllText($ragPath).Trim()
        if ([string]::IsNullOrWhiteSpace($ragCipher)) { throw 'Empty credential' }
        return Unprotect-RagSecret $ragCipher
    }
    catch { throw '无法解密已保存密钥。请使用原 Windows 用户，或通过更换密钥入口重新输入。' }
}
function Save-RagCredential([string]$AppRoot, [Security.SecureString]$Secret) {
    if ($null -eq $Secret -or $Secret.Length -eq 0) { throw '不能保存空密钥。' }
    $ragPath = Get-RagCredentialPath $AppRoot
    $ragDirectory = [IO.Path]::GetDirectoryName($ragPath)
    $ragTemporary = [IO.Path]::Combine($ragDirectory, ('.credential-' + [Guid]::NewGuid().ToString('N') + '.tmp'))
    try {
        $ragCipher = Protect-RagSecret $Secret
        [void][IO.Directory]::CreateDirectory($ragDirectory)
        [IO.File]::WriteAllText($ragTemporary, $ragCipher, [Text.UTF8Encoding]::new($false))
        if ([IO.File]::Exists($ragPath)) { [IO.File]::Replace($ragTemporary, $ragPath, [NullString]::Value) }
        else { [IO.File]::Move($ragTemporary, $ragPath) }
    }
    catch { throw 'Windows 加密保存失败，请检查目录权限后重试。' }
    finally { if ([IO.File]::Exists($ragTemporary)) { [IO.File]::Delete($ragTemporary) } }
}
function Clear-RagCredential([string]$AppRoot) {
    $ragPath = Get-RagCredentialPath $AppRoot
    try { if ([IO.File]::Exists($ragPath)) { [IO.File]::Delete($ragPath) } }
    catch { throw '未能清除本机保存的密钥，请检查目录权限。' }
}
function Get-RagPlainKey([Security.SecureString]$Secret) {
    $ragPointer = [IntPtr]::Zero
    try {
        $ragPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Secret)
        return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ragPointer)
    }
    finally { if ($ragPointer -ne [IntPtr]::Zero) { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ragPointer) } }
}
function Normalize-RagInput([string]$Value) {
    $ragValue = $Value.Replace([string][char]22, '').Trim([char[]]" `t`r`n$([char]0xfeff)$([char]0x200b)$([char]0x2060)")
    $ragPairs = @(@('"','"'), @("'", "'"), @('“','”'), @('‘','’'), @('`','`'))
    foreach ($ragPair in $ragPairs) {
        if ($ragValue.Length -gt 1 -and $ragValue.StartsWith($ragPair[0]) -and $ragValue.EndsWith($ragPair[1])) {
            $ragValue = $ragValue.Substring(1, $ragValue.Length - 2).Trim()
            break
        }
    }
    if ($ragValue.StartsWith('Bearer ', [StringComparison]::OrdinalIgnoreCase)) { $ragValue = $ragValue.Substring(7).Trim() }
    return $ragValue
}
function Test-RagInput([string]$Value) {
    return ($Value -match '^[\x21-\x7e]{1,8192}$' -and $Value -notmatch '\*|\.\.\.')
}
