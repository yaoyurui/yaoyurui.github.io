@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
title BigModel RAG Assistant
set "RAG_PY=%~dp0.venv\Scripts\python.exe"
if /i "%~1"=="--self-test" goto self_test
if exist "%RAG_PY%" (
  "%RAG_PY%" "%~dp0credential_selftest.py"
) else (
  py -3 "%~dp0credential_selftest.py"
)
pause
exit /b
:self_test
if exist "%RAG_PY%" (
  "%RAG_PY%" "%~dp0credential_selftest.py" --self-test
) else (
  py -3 "%~dp0credential_selftest.py" --self-test
)
exit /b
