@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
title Test Version Comparison Assistant
if not exist "%~dp0app.py" (
  echo app.py is missing. Extract the entire ZIP file before starting.
  pause
  exit /b 1
)
if not exist "%~dp0index.html" (
  echo index.html is missing. Keep app.py and index.html in the same folder.
  pause
  exit /b 1
)
if not exist "%~dp0quality_rules.py" (
  echo quality_rules.py is missing. Extract the entire latest package before starting.
  pause
  exit /b 1
)
for %%F in (rag_service.py standard_parser.py provider_connection.py quality-ui.js) do (
  if not exist "%~dp0%%F" (
    echo %%F is missing. Extract the complete RAG package before starting.
    pause
    exit /b 1
  )
)
set "DEMO_PY=C:\Users\xy\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
if exist "%DEMO_PY%" (
  "%DEMO_PY%" "%~dp0app.py" --open
) else (
  py -3 "%~dp0app.py" --open
)
if errorlevel 1 pause
