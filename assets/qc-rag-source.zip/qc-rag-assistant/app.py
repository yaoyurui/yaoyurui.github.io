"""Local deterministic comparison with optional environment-configured RAG."""
import argparse
import base64
import csv
import html
import io
import json
import os
import posixpath
import socket
import sys
import threading
import urllib.request
import webbrowser
import zipfile
from collections import Counter
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit
from xml.etree import ElementTree as ET
from quality_rules import QualityService, RuleError
from rag_service import RagService, public_config

ROOT = Path(__file__).resolve().parent
APP_ID = "local-test-version-comparison-v1"
APP_VERSION = "2026.11.01.bigmodel.5"
NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
MAX_ROWS = 5000
MAX_FILE = 10 * 1024 * 1024
STATUSES = ["已修复", "新增错误", "持续错误", "保持正确", "标签待确认",
            "标签已变更", "数据不完整", "仅旧版", "仅新版"]
COMPARABLE = set(STATUSES[:4])
ALIASES = {
    "id": {"样本编号", "样本ID", "样本id", "sample_id", "id"},
    "label": {"人工标签", "真实标签", "已确认标签", "ground_truth", "label"},
    "prediction": {"模型预测结果", "模型预测", "预测结果", "prediction", "pred"},
    "state": {"标签状态", "人工标签状态", "label_status"},
    "product": {"适用产品", "产品", "产品型号", "product"},
    "part": {"部位", "检测部位", "part"},
    "observations": {"现场观察", "补充信息", "observations"},
}
PENDING = {"待确认", "争议", "有争议", "未确认", "pending", "unknown", "disputed"}
CONFIRMED = {"", "已确认", "确认", "confirmed"}


class InputError(ValueError):
    def __init__(self, message, details=None):
        super().__init__(message)
        self.details = details or []


class Formula:
    pass


def text(value):
    return "" if value is None else str(value).strip()


def csv_matrix(data):
    for encoding in ("utf-8-sig", "gb18030"):
        try:
            content = data.decode(encoding)
            break
        except UnicodeDecodeError:
            continue
    else:
        raise InputError("CSV 编码无法识别，请另存为 UTF-8 CSV。")
    try:
        dialect = csv.Sniffer().sniff(content[:8192], delimiters=",;\t")
    except csv.Error:
        dialect = csv.excel
    matrix = []
    try:
        for row in csv.reader(io.StringIO(content), dialect):
            matrix.append(row)
            if len(matrix) > MAX_ROWS + 20:
                raise InputError("每个文件最多支持 5000 条数据。")
    except csv.Error as exc:
        raise InputError("CSV 格式无法读取。") from exc
    return matrix, "CSV"


def xlsx_matrix(data):
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            if sum(item.file_size for item in archive.infolist()) > 50 * 1024 * 1024:
                raise InputError("Excel 解压后过大，请仅保留本次需要的测试数据。")
            workbook = ET.fromstring(archive.read("xl/workbook.xml"))
            sheets = workbook.findall("m:sheets/m:sheet", NS)
            if not sheets:
                raise InputError("Excel 没有工作表。")
            sheet = sheets[0]
            rel_id = sheet.attrib.get(
                "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id")
            rels = ET.fromstring(archive.read("xl/_rels/workbook.xml.rels"))
            target = next((r.attrib["Target"] for r in rels
                           if r.attrib.get("Id") == rel_id), None)
            if not target:
                raise InputError("Excel 工作表关系无效。")
            path = target.lstrip("/") if target.startswith("/") else posixpath.normpath("xl/" + target)
            shared = []
            if "xl/sharedStrings.xml" in archive.namelist():
                for item in ET.fromstring(archive.read("xl/sharedStrings.xml")).findall("m:si", NS):
                    shared.append("".join(item.itertext()))
            matrix = []
            sheet_xml = ET.fromstring(archive.read(path))
            for row in sheet_xml.findall("m:sheetData/m:row", NS):
                cells = {}
                for cell in row.findall("m:c", NS):
                    ref = cell.attrib.get("r", "")
                    letters = "".join(c for c in ref if c.isalpha()).upper()
                    column = 0
                    for c in letters:
                        column = column * 26 + ord(c) - 64
                    if not column or column > 200:
                        continue
                    if cell.find("m:f", NS) is not None:
                        value = Formula()
                    elif cell.attrib.get("t") == "inlineStr":
                        value = "".join(cell.find("m:is", NS).itertext())
                    else:
                        raw = cell.findtext("m:v", default="", namespaces=NS)
                        value = shared[int(raw)] if cell.attrib.get("t") == "s" else raw
                    cells[column - 1] = value
                matrix.append([cells.get(i, "") for i in range(max(cells, default=-1) + 1)])
                if len(matrix) > MAX_ROWS + 20:
                    raise InputError("每个文件最多支持 5000 条数据。")
            return matrix, sheet.attrib.get("name", "首个工作表")
    except InputError:
        raise
    except (zipfile.BadZipFile, KeyError, ET.ParseError, ValueError, IndexError) as exc:
        raise InputError("无法读取 Excel，请使用未加密的 .xlsx 文件。") from exc


def normalize(matrix, side):
    matrix = list(matrix)
    while matrix and not any(text(x) for x in matrix[0]):
        matrix.pop(0)
    if not matrix:
        raise InputError(side + "文件为空。")
    header = [text(x).replace("\ufeff", "") for x in matrix[0]]
    mapping = {}
    for key, aliases in ALIASES.items():
        matches = [i for i, name in enumerate(header)
                   if name.casefold() in {a.casefold() for a in aliases}]
        if len(matches) > 1:
            raise InputError(side + "表头存在重复或含义相同的列：" + key)
        if matches:
            mapping[key] = matches[0]
    missing = [key for key in ("id", "label", "prediction") if key not in mapping]
    if missing:
        raise InputError(side + "缺少必要列。", ["需要：样本编号、人工标签、模型预测结果；可选：标签状态。"])
    records = {}
    issues = []
    count = 0
    for row_number, raw_row in enumerate(matrix[1:], 2):
        if not any(text(v) for v in raw_row):
            continue
        count += 1
        if count > MAX_ROWS:
            raise InputError("每个文件最多支持 5000 条数据。")
        record = {}
        for key, column in mapping.items():
            value = raw_row[column] if column < len(raw_row) else ""
            if isinstance(value, Formula):
                issues.append(f"{side}第 {row_number} 行包含公式，请粘贴为值后再导入。")
                value = ""
            record[key] = text(value)
            if key in ("product", "part", "observations") and len(record[key]) > (2000 if key == "observations" else 120):
                issues.append(f"{side}第 {row_number} 行补充信息过长：{key}。")
        record.setdefault("state", "")
        record["row"] = row_number
        identifier = record["id"]
        if not identifier:
            issues.append(f"{side}第 {row_number} 行缺少样本编号。")
        elif identifier in records:
            issues.append(f"{side}样本编号重复：{identifier}（第 {records[identifier]['row']}、{row_number} 行）。")
        else:
            records[identifier] = record
    if issues:
        raise InputError("编号或字段校验未通过，请修正后重新导入。", issues[:50])
    if not records:
        raise InputError(side + "没有数据行。")
    return records


def read_file(payload, side):
    if not isinstance(payload, dict):
        raise InputError(side + "文件未提供。")
    name = str(payload.get("name", ""))
    try:
        data = base64.b64decode(payload.get("data", ""), validate=True)
    except (ValueError, TypeError) as exc:
        raise InputError(side + "文件传输无效。") from exc
    if not data or len(data) > MAX_FILE:
        raise InputError(side + "文件为空或超过 10 MB。")
    if name.lower().endswith(".xlsx"):
        matrix, sheet = xlsx_matrix(data)
    elif name.lower().endswith((".csv", ".tsv")):
        matrix, sheet = csv_matrix(data)
    else:
        raise InputError("支持 .xlsx、.csv、.tsv；旧版 .xls 请另存为 .xlsx。")
    records = normalize(matrix, side)
    return records, {"name": name, "sheet": sheet, "rows": len(records)}


def compare(old, new, old_meta=None, new_meta=None, demo=False):
    rows = []
    for identifier in sorted(set(old) | set(new)):
        before, after = old.get(identifier), new.get(identifier)
        reason = ""
        if before is None:
            status, reason = "仅新版", "旧版无对应编号，不纳入版本效果比较。"
        elif after is None:
            status, reason = "仅旧版", "新版无对应编号，不纳入版本效果比较。"
        else:
            states = [before["state"].casefold(), after["state"].casefold()]
            labels = [before["label"], after["label"]]
            if any(s not in CONFIRMED or label.casefold() in PENDING
                   for s, label in zip(states, labels)):
                status, reason = "标签待确认", "标签有争议或状态未确认，需人工复核。"
            elif not all(labels):
                status, reason = "数据不完整", "人工标签为空，无法判断预测是否正确。"
            elif labels[0] != labels[1]:
                status, reason = "标签已变更", "两版人工标签不同，需统一参照后重算旧、新预测。"
            elif not before["prediction"] or not after["prediction"]:
                status, reason = "数据不完整", "某一版本缺少模型预测结果。"
            else:
                old_ok = before["prediction"] == labels[0]
                new_ok = after["prediction"] == labels[1]
                status = {(False, True): "已修复", (True, False): "新增错误",
                          (False, False): "持续错误", (True, True): "保持正确"}[(old_ok, new_ok)]
                reason = {"已修复": "旧版错误，新版正确。",
                          "新增错误": "旧版正确，新版错误。",
                          "持续错误": "两版均与同一人工标签不一致。",
                          "保持正确": "两版均与同一人工标签一致。"}[status]
        rows.append({"id": identifier, "old_label": before["label"] if before else "",
                     "new_label": after["label"] if after else "",
                     "old_prediction": before["prediction"] if before else "",
                     "new_prediction": after["prediction"] if after else "",
                     "status": status, "reason": reason})
        # Preserve contextual fields without changing any comparison/category rules.
        context = {side + "_" + field: record.get(field, "")
                   for side, record in (("old", before), ("new", after)) if record
                   for field in ("product", "part", "observations") if record.get(field)}
        if context:
            rows[-1]["inspection_context"] = context
    counts = {s: 0 for s in STATUSES}
    counts.update(Counter(r["status"] for r in rows))
    comparable = sum(counts[s] for s in COMPARABLE)
    review = len(rows) - comparable
    summary = (f"本次按样本编号合并 {len(rows)} 条记录，其中 {comparable} 条满足同一人工标签、"
               f"标签已确认且两版预测完整的比较条件。已修复 {counts['已修复']} 条，"
               f"新增错误 {counts['新增错误']} 条，持续错误 {counts['持续错误']} 条，"
               f"保持正确 {counts['保持正确']} 条。另有 {review} 条需核对标签、数据完整性或样本覆盖。")
    if not comparable:
        summary += "当前没有可比样本，不能判断版本效果变化。"
    return {"rows": rows, "counts": counts, "total": len(rows), "comparable": comparable,
            "review": review, "old_errors": counts["已修复"] + counts["持续错误"],
            "new_errors": counts["新增错误"] + counts["持续错误"],
            "summary": summary, "demo": demo, "old_file": old_meta, "new_file": new_meta,
            "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
            "method": "版本统计与本次摘要由确定性规则计算；RAG 建议独立于统计，不据此推断产线总体效果。"}


def demo_matrices():
    header = ["样本编号", "人工标签", "模型预测结果", "标签状态"]
    old, new = [header], [header]
    for i in range(1, 31):
        label = ["划痕", "脏污", "异物", "正常", "开胶"][i % 5]
        wrong = "脏污" if label != "脏污" else "划痕"
        a = [f"SIM-{i:03}", label, label, "已确认"]
        b = list(a)
        if i <= 6:
            a[2] = wrong
        elif i <= 10:
            b[2] = wrong
        elif i <= 15:
            a[2] = b[2] = wrong
        elif i in (23, 24):
            a[3] = b[3] = "待确认"
        elif i == 25:
            b[1] = wrong
        elif i == 26:
            a[2] = ""
        elif i == 27:
            b[2] = ""
        elif i == 28:
            a[1] = ""
        if i != 30:
            old.append(a)
        if i != 29:
            new.append(b)
    return old, new


def demo_result():
    a, b = demo_matrices()
    result = compare(normalize(a, "旧版"), normalize(b, "新版"),
                   {"name": "模拟旧版.xlsx", "sheet": "样本", "rows": len(a) - 1},
                   {"name": "模拟新版.xlsx", "sheet": "样本", "rows": len(b) - 1}, True)
    for row in result["rows"]:
        row["inspection_context"] = {"new_product": "演示电视A", "new_part": "屏幕表面",
            "new_observations": "模拟样本：仅有标签及预测记录，没有上传图片或实物证据；需核查原图、拍摄条件和现场记录。"}
    return result


def csv_text(result, reviews=None):
    reviews = reviews or {}
    stream = io.StringIO(newline="")
    writer = csv.writer(stream)
    writer.writerow(["样本编号", "旧版人工标签", "新版人工标签", "旧版预测", "新版预测",
                     "对比结果", "说明", "复核状态", "人工复核结论", "复核人", "复核时间",
                     "适用产品", "规则出处", "条款摘录", "备注", "RAG查询编号", "RAG状态", "模型建议快照"])
    for row in result["rows"]:
        values = [row[k] for k in ("id", "old_label", "new_label", "old_prediction",
                                  "new_prediction", "status", "reason")]
        review = reviews.get(row["id"], {})
        citations = review.get("citations", [])
        values += [review.get("state", ""), review.get("final_label", ""),
                   review.get("reviewer", ""), review.get("created_at", ""),
                   review.get("product", ""),
                   "\n".join(c["title"] + " / " + c["version"] + " / " + c["clause_id"] +
                             " / " + c["location"] + (" / 模拟资料" if c["is_demo"] else "")
                             for c in citations),
                   "\n\n".join(c["excerpt"] for c in citations), review.get("note", "")]
        rag = review.get("rag", {})
        values += [rag.get("run_id", ""), rag.get("status", ""),
                   json.dumps(rag["answer"], ensure_ascii=False) if rag.get("answer") else ""]
        writer.writerow(["'" + v if v.startswith(("=", "+", "-", "@", "\t", "\r")) else v
                         for v in values])
    return stream.getvalue()


class LocalServer(ThreadingHTTPServer):
    allow_reuse_address = False

    def __init__(self, *args, **kwargs):
        self.quality = QualityService(ROOT, os.environ.get("QC_REVIEW_DATA_DIR"))
        self.rag = RagService(self.quality)
        self.quality.rag = self.rag
        super().__init__(*args, **kwargs)

    def server_bind(self):
        if os.name == "nt" and hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        super().server_bind()


class Handler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass

    def respond(self, status, content, content_type="application/json; charset=utf-8"):
        if isinstance(content, dict):
            content = json.dumps(content, ensure_ascii=False).encode("utf-8")
        elif isinstance(content, str):
            content = content.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(content)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(content)

    def prepare_result(self, result):
        self.server.quality.register(result)
        result["reviews"] = self.server.quality.reviews(result["comparison_id"])
        result["csv"] = csv_text(result, result["reviews"])
        return result

    def do_GET(self):
        host = self.headers.get("Host", "")
        if host != f"127.0.0.1:{self.server.server_port}":
            self.respond(403, {"error": "Host not allowed"})
            return
        parsed = urlsplit(self.path)
        params = parse_qs(parsed.query)
        value = lambda name: params.get(name, [""])[0]
        try:
            if parsed.path == "/api/rag/status":
                self.respond(200, {**public_config(), "app_version": APP_VERSION})
                return
            if parsed.path == "/api/rag/history":
                self.respond(200, {"history": self.server.rag.history(value("comparison_id"), value("sample_id"))})
                return
            if parsed.path == "/api/rules/catalog":
                self.respond(200, self.server.quality.catalog())
                return
            if parsed.path == "/rules/source":
                self.respond(200, self.server.quality.source_html(value("id"), value("hash")),
                             "text/html; charset=utf-8")
                return
            if parsed.path == "/api/reviews":
                comparison_id = value("comparison_id")
                self.respond(200, {"reviews": self.server.quality.reviews(comparison_id)})
                return
            if parsed.path == "/api/reviews/history":
                self.respond(200, {"history": self.server.quality.history(
                    value("comparison_id"), value("sample_id"))})
                return
            if parsed.path == "/api/reviews/export":
                comparison_id = value("comparison_id")
                result = self.server.quality.comparison(comparison_id)
                self.respond(200, "\ufeff" + csv_text(
                    result, self.server.quality.reviews(comparison_id)), "text/csv; charset=utf-8")
                return
        except RuleError as exc:
            self.respond(exc.status, {"error": str(exc)})
            return
        except Exception:
            self.respond(500, {"error": "标准或复核记录暂时无法读取，请检查本地文件是否可用。"})
            return
        if self.path == "/api/health":
            ready = (ROOT / "index.html").is_file()
            self.respond(200 if ready else 503, {
                "app": APP_ID, "version": APP_VERSION, "ready": ready, "root": str(ROOT), "pid": os.getpid()
            })
        elif self.path == "/":
            try:
                content = (ROOT / "index.html").read_bytes()
            except OSError:
                location = html.escape(str(ROOT))
                self.respond(503,
                    '<!doctype html><html lang="zh-CN"><meta charset="utf-8">'
                    '<title>请重新启动助手</title><body style="font:16px/1.8 system-ui;padding:40px">'
                    '<h1>程序目录已移动或页面文件缺失</h1>'
                    '<p>请关闭旧的启动窗口，在文件当前所在目录重新双击 start.cmd。</p>'
                    '<p>移动文件夹后，已经运行的服务不会自动切换目录。</p>'
                    '<p>此服务仍在读取：' + location + '</p></body></html>',
                    "text/html; charset=utf-8")
                return
            self.respond(200, content, "text/html; charset=utf-8")
        elif self.path == "/api/demo":
            self.respond(200, self.prepare_result(demo_result()))
        elif self.path == "/quality-ui.js":
            self.respond(200, (ROOT / "quality-ui.js").read_bytes(), "text/javascript; charset=utf-8")
        elif self.path.startswith("/samples/"):
            names = {"old.xlsx": "模拟旧版.xlsx", "new.xlsx": "模拟新版.xlsx",
                     "trial.xlsx": "试用记录模板.xlsx"}
            key = self.path.removeprefix("/samples/")
            target = ROOT / "samples" / names.get(key, "__missing__")
            if key in names and target.is_file():
                self.respond(200, target.read_bytes(),
                             "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
            else:
                self.respond(404, {"error": "File not found"})
        else:
            self.respond(404, {"error": "Not found"})

    def do_POST(self):
        allowed = f"127.0.0.1:{self.server.server_port}"
        if self.headers.get("Host") != allowed or self.headers.get("Origin") not in (
                None, "http://" + allowed):
            # Drain only small rejected bodies so Windows can deliver 403 before closing,
            # rather than resetting the connection with unread request bytes.
            try:
                rejected_size = int(self.headers.get("Content-Length", "0"))
                if 0 < rejected_size <= 65536:
                    self.connection.settimeout(3)
                    self.rfile.read(rejected_size)
            except (ValueError, OSError):
                pass
            self.respond(403, {"error": "不允许跨站请求。"})
            return
        if self.path not in ("/api/compare", "/api/rules/search", "/api/reviews", "/api/rag/run"):
            self.respond(404, {"error": "Not found"})
            return
        try:
            size = int(self.headers.get("Content-Length", "0"))
            if size <= 0 or size > 28 * 1024 * 1024:
                raise InputError("请求为空或过大。")
            data = json.loads(self.rfile.read(size))
            if not isinstance(data, dict):
                raise InputError("请求格式错误。")
            if self.path == "/api/rag/run":
                self.respond(200, self.server.rag.run(data))
                return
            if self.path == "/api/rules/search":
                self.respond(200, self.server.quality.search(
                    data.get("query", ""), data.get("product", ""),
                    data.get("include_history", False), data.get("version", ""), data.get("part", "")))
                return
            if self.path == "/api/reviews":
                record = self.server.quality.save_review(data)
                self.respond(200, {"review": record})
                return
            old, old_meta = read_file(data.get("old"), "旧版")
            new, new_meta = read_file(data.get("new"), "新版")
            simulated = "模拟" in old_meta["name"] and "模拟" in new_meta["name"]
            result = compare(old, new, old_meta, new_meta, demo=simulated)
            self.respond(200, self.prepare_result(result))
        except RuleError as exc:
            self.respond(exc.status, {"error": str(exc)})
        except InputError as exc:
            self.respond(422, {"error": str(exc), "details": exc.details})
        except (ValueError, TypeError, UnicodeError):
            self.respond(400, {"error": "文件或请求格式无效。"})
        except Exception:
            self.respond(500, {"error": "处理失败，请检查文件是否符合模板。"})


def existing_instance(port):
    try:
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(f"http://127.0.0.1:{port}/api/health", timeout=0.8) as response:
            state = json.load(response)
        return (state.get("app") == APP_ID and state.get("version") == APP_VERSION and state.get("ready") is True
                and Path(state.get("root", "")) == ROOT)
    except Exception:
        return False


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser()
    parser.add_argument("--open", action="store_true")
    parser.add_argument("--port", type=int, default=8765)
    args = parser.parse_args()
    if not (ROOT / "index.html").is_file():
        raise SystemExit("index.html is missing. Extract the entire folder before starting.")
    server = None
    for port in range(args.port, args.port + 20):
        if existing_instance(port):
            url = f"http://127.0.0.1:{port}"
            print("The assistant is already running: " + url, flush=True)
            if args.open:
                webbrowser.open(url)
            return
        try:
            server = LocalServer(("127.0.0.1", port), Handler)
            break
        except OSError:
            continue
    if server is None:
        raise SystemExit("No available local port.")
    url = f"http://127.0.0.1:{server.server_port}"
    print("Version comparison assistant: " + url, flush=True)
    print("Program folder: " + str(ROOT), flush=True)
    print("Keep this window open. Press Ctrl+C to stop.", flush=True)
    print("Before moving this folder, stop the program and then restart from the new folder.", flush=True)
    if args.open:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
