import base64
import copy
import csv
import importlib.util
import io
import json
import os
import shutil
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from pathlib import Path

APP=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(APP))
from quality_rules import QualityService,RuleError
import app


class RuleTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.root=Path(self.temp.name)
        shutil.copytree(APP/"standards",self.root/"standards")
        self.service=QualityService(self.root)
        self.result=app.demo_result()
        self.id=self.service.register(self.result)
        self.hit=self.service.search("划痕 脏污","演示电视A")["results"][0]

    def tearDown(self):
        self.temp.cleanup()

    def payload(self,**changes):
        data={"comparison_id":self.id,"sample_id":"SIM-023","product":"演示电视A",
              "reviewer":"自动验证人员（模拟）","state":"已确认","final_label":"划痕",
              "note":"自动检查，不是真人试用","query":"划痕 脏污",
              "authority_confirmed":True,"citations":[self.hit]}
        data.update(changes)
        return data

    def test_default_current_and_product_filter(self):
        hits=self.service.search("划痕 脏污","演示电视A")["results"]
        self.assertTrue(hits)
        self.assertTrue(all(h["product"]=="演示电视A" and h["status"]=="current" for h in hits))
        self.assertTrue(all(h["version"]=="v2.0" for h in hits))

    def test_product_b_not_a(self):
        hits=self.service.search("划痕","演示电视B")["results"]
        self.assertTrue(hits)
        self.assertTrue(all(h["product"]=="演示电视B" for h in hits))

    def test_archived_only_when_requested(self):
        self.assertFalse(self.service.search("划痕","演示电视A",False,"v1.0")["results"])
        hits=self.service.search("划痕","演示电视A",True,"v1.0")["results"]
        self.assertTrue(hits)
        self.assertTrue(all(h["status"]=="archived" for h in hits))

    def test_no_product_rejected(self):
        with self.assertRaises(RuleError):
            self.service.search("划痕","")

    def test_no_unrelated_fallback(self):
        self.assertEqual(self.service.search("火星量子xyz789","演示电视A")["results"],[])

    def test_exact_source_and_location(self):
        hit=self.hit
        document=next(d for d in self.service.documents() if d["id"]==hit["id"])
        clause=next(c for c in document["clauses"] if c["clause_id"]==hit["clause_id"])
        self.assertEqual(hit["excerpt"],clause["text"])
        source=self.service.source_html(hit["id"],hit["hash"])
        self.assertIn('id="L'+str(clause["start_line"])+'"',source)
        self.assertIn("模拟资料",source)

    def test_confirmed_review_persists_and_counts_unchanged(self):
        before=copy.deepcopy(self.result)
        saved=self.service.save_review(self.payload())
        reopened=QualityService(self.root)
        record=reopened.reviews(self.id)["SIM-023"]
        self.assertEqual(saved,record)
        self.assertEqual(record["citations"][0]["excerpt"],self.hit["excerpt"])
        self.assertEqual(before["counts"],reopened.comparison(self.id)["counts"])
        self.assertEqual(before["rows"],reopened.comparison(self.id)["rows"])

    def test_confirmation_requires_authority(self):
        with self.assertRaises(RuleError):
            self.service.save_review(self.payload(authority_confirmed=False))

    def test_confirmation_requires_citation(self):
        with self.assertRaises(RuleError):
            self.service.save_review(self.payload(citations=[]))

    def test_pending_without_citation_allowed(self):
        saved=self.service.save_review(self.payload(state="待确认",final_label="",citations=[],authority_confirmed=False))
        self.assertEqual(saved["state"],"待确认")

    def test_simulated_rules_cannot_confirm_real_data(self):
        result=copy.deepcopy(self.result);result["demo"]=False
        identifier=self.service.register(result)
        with self.assertRaises(RuleError):
            self.service.save_review(self.payload(comparison_id=identifier))

    def test_cross_product_citation_rejected(self):
        other=self.service.search("划痕","演示电视B")["results"][0]
        with self.assertRaises(RuleError):
            self.service.save_review(self.payload(citations=[other]))

    def test_old_version_cannot_confirm(self):
        old=self.service.search("划痕","演示电视A",True,"v1.0")["results"][0]
        with self.assertRaises(RuleError):
            self.service.save_review(self.payload(citations=[old]))
        saved=self.service.save_review(self.payload(citations=[old],state="待确认"))
        self.assertEqual(saved["citations"][0]["status"],"archived")

    def test_changed_document_rejected_but_snapshot_kept(self):
        first=self.service.save_review(self.payload())
        file=self.root/"standards"/self.hit["source_file"]
        file.write_text(file.read_text(encoding="utf-8")+"\n追加模拟修订。\n",encoding="utf-8")
        with self.assertRaises(RuleError) as caught:
            self.service.save_review(self.payload())
        self.assertEqual(caught.exception.status,409)
        self.assertEqual(self.service.reviews(self.id)["SIM-023"]["citations"],first["citations"])
        with self.assertRaises(RuleError):
            self.service.source_html(self.hit["id"],self.hit["hash"])

    def test_comparison_isolation(self):
        changed=copy.deepcopy(self.result)
        changed["rows"][0]["new_prediction"]="另一结果"
        second=self.service.register(changed)
        self.service.save_review(self.payload())
        self.assertNotEqual(second,self.id)
        self.assertEqual(self.service.reviews(second),{})

    def test_append_history_and_latest(self):
        first=self.service.save_review(self.payload(note="第一次"))
        second=self.service.save_review(self.payload(note="第二次"))
        self.assertNotEqual(first["record_id"],second["record_id"])
        self.assertEqual(len(self.service.history(self.id,"SIM-023")),2)
        self.assertEqual(self.service.reviews(self.id)["SIM-023"]["note"],"第二次")

    def test_invalid_sample_rejected(self):
        with self.assertRaises(RuleError):
            self.service.save_review(self.payload(sample_id="NOT-IN-DATA"))

    def test_export_contains_snapshot(self):
        self.service.save_review(self.payload())
        exported=app.csv_text(self.result,self.service.reviews(self.id))
        rows=list(csv.reader(io.StringIO(exported)))
        record=next(r for r in rows[1:] if r[0]=="SIM-023")
        self.assertEqual(record[7],"已确认")
        self.assertIn("v2.0",record[12])
        self.assertIn(self.hit["excerpt"],record[13])
        self.assertEqual(len(rows),31)

    def test_plain_html_escaping(self):
        target=self.root/"standards"/self.hit["source_file"]
        target.write_text(target.read_text(encoding="utf-8")+"\n<script>alert(1)</script>\n",encoding="utf-8")
        output=self.service.source_html(self.hit["id"])
        self.assertNotIn("<script>alert",output)
        self.assertIn("&lt;script&gt;",output)


class ApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory()
        cls.previous=os.environ.get("QC_REVIEW_DATA_DIR")
        os.environ["QC_REVIEW_DATA_DIR"]=cls.temp.name
        cls.server=app.LocalServer(("127.0.0.1",0),app.Handler)
        cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True)
        cls.thread.start()
        cls.url=f"http://127.0.0.1:{cls.server.server_port}"
        cls.opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown();cls.server.server_close()
        if cls.previous is None:os.environ.pop("QC_REVIEW_DATA_DIR",None)
        else:os.environ["QC_REVIEW_DATA_DIR"]=cls.previous
        cls.temp.cleanup()

    def fetch(self,path,data=None,origin=None):
        request=urllib.request.Request(self.url+path,data=None if data is None else json.dumps(data).encode(),
            headers={} if data is None else {"Content-Type":"application/json","Origin":origin or self.url})
        return self.opener.open(request,timeout=5)

    def test_full_api_review_flow(self):
        with self.fetch("/api/demo") as r:result=json.load(r)
        self.assertEqual(result["comparable"],22)
        with self.fetch("/api/rules/search",{"query":"划痕 脏污","product":"演示电视A"}) as r:
            hit=json.load(r)["results"][0]
        payload={"comparison_id":result["comparison_id"],"sample_id":"SIM-024","product":"演示电视A",
                 "reviewer":"接口验证（模拟）","state":"已确认","final_label":"脏污",
                 "authority_confirmed":True,"citations":[hit]}
        with self.fetch("/api/reviews",payload) as r:self.assertEqual(json.load(r)["review"]["state"],"已确认")
        with self.fetch("/api/reviews/export?comparison_id="+result["comparison_id"]) as r:
            self.assertIn("接口验证（模拟）",r.read().decode("utf-8-sig"))
        with self.fetch("/api/demo") as r:again=json.load(r)
        self.assertEqual(again["counts"],result["counts"])
        self.assertIn("SIM-024",again["reviews"])

    def test_cross_origin_blocked(self):
        with self.assertRaises(urllib.error.HTTPError) as caught:
            self.fetch("/api/rules/search",{"query":"划痕","product":"演示电视A"},"https://example.invalid")
        self.assertEqual(caught.exception.code,403)

    def test_healthy_assets(self):
        with self.fetch("/api/health") as r:self.assertEqual(json.load(r)["version"],app.APP_VERSION)
        with self.fetch("/quality-ui.js") as r:self.assertIn("openReview",r.read().decode())


if __name__=="__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    unittest.main(verbosity=2)
