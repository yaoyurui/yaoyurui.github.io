"""Transport compatibility and redaction tests; no external requests."""
import io
import json
import sys
import unittest
import urllib.error
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import provider_connection as connection
from rag_service import NoRedirect


class Response:
    def __init__(self, value): self.value = value
    def __enter__(self): return self
    def __exit__(self, *args): pass
    def read(self, n): return json.dumps(self.value).encode()


class ConnectionTests(unittest.TestCase):
    def error(self, code, body):
        return urllib.error.HTTPError('https://api.deepseek.com/models', code, 'error', {}, io.BytesIO(body))

    def test_400_primary_uses_v1_route(self):
        requests = []
        class Opener:
            def open(inner, request, timeout):
                requests.append(request)
                if len(requests) == 1:
                    raise self.error(400, b'{"error":{"message":"invalid request"}}')
                return Response({'data': [{'id': 'deepseek-chat'}]})
        with patch.object(connection.urllib.request, 'getproxies', return_value={}), \
             patch.object(connection.urllib.request, 'build_opener', return_value=Opener()):
            models, diagnostic = connection.discover('sk-dummy-local-only', NoRedirect)
        self.assertEqual(models, ['deepseek-chat'])
        self.assertEqual(requests[1].full_url, 'https://api.deepseek.com/v1/models')
        self.assertEqual(requests[0].get_method(), 'GET')
        self.assertEqual(diagnostic['status'], 'models_available')

    def test_401_no_retry_and_secret_redacted(self):
        requests = []
        secret = 'sk-sensitive-test-123456789'
        class Opener:
            def open(inner, request, timeout):
                requests.append(request)
                raise self.error(401, json.dumps({'error': {'message': 'bad key '+secret}}).encode())
        with patch.object(connection.urllib.request, 'getproxies', return_value={}), \
             patch.object(connection.urllib.request, 'build_opener', return_value=Opener()), \
             self.assertRaises(connection.DiscoveryError) as caught:
            connection.discover(secret, NoRedirect)
        self.assertEqual(len(requests), 1)
        self.assertEqual(caught.exception.status, 401)
        self.assertNotIn(secret, json.dumps(caught.exception.attempts))

    def test_proxy_400_tries_direct_same_host(self):
        requests = []
        class Opener:
            def open(inner, request, timeout):
                requests.append(request.full_url)
                if len(requests) == 1:
                    raise self.error(400, b'Bad request from proxy')
                return Response({'data': [{'id': 'deepseek-flash'}]})
        with patch.object(connection.urllib.request, 'getproxies', return_value={'https':'http://127.0.0.1:7890'}), \
             patch.object(connection.urllib.request, 'build_opener', return_value=Opener()):
            _, diagnostic = connection.discover('dummy-key', NoRedirect)
        self.assertEqual(requests[0], requests[1])
        self.assertEqual(diagnostic['network'], 'direct')

    def test_exhausted_routes_keep_safe_reason(self):
        secret = 'sk-sensitive-test-123456789'
        class Opener:
            def open(inner, request, timeout):
                raise self.error(400, ('<html><body>Invalid header '+secret+'</body></html>').encode())
        with patch.object(connection.urllib.request, 'getproxies', return_value={}), \
             patch.object(connection.urllib.request, 'build_opener', return_value=Opener()), \
             self.assertRaises(connection.DiscoveryError) as caught:
            connection.discover(secret, NoRedirect)
        self.assertEqual(len(caught.exception.attempts), 2)
        self.assertEqual(caught.exception.attempts[0]['body_kind'], 'html')
        self.assertNotIn(secret, caught.exception.reason)
        self.assertNotIn('<html>', caught.exception.reason)

    def test_no_usable_models_not_false_success(self):
        class Opener:
            def open(inner, request, timeout): return Response({'data': [{'id': 'not-a-deepseek-model'}]})
        with patch.object(connection.urllib.request, 'getproxies', return_value={}), \
             patch.object(connection.urllib.request, 'build_opener', return_value=Opener()), \
             self.assertRaises(connection.DiscoveryError):
            connection.discover('dummy-key', NoRedirect)

    def test_redaction_handles_bearer_and_long_tokens(self):
        secret = 'private-secret-for-test'
        result = connection.redact_reason('Authorization: Bearer '+secret+' sk-abcdef123456 token'+'X'*50, secret)
        self.assertNotIn(secret, result)
        self.assertNotIn('sk-abcdef123456', result)
        self.assertNotIn('X'*30, result)


if __name__ == '__main__': unittest.main(verbosity=2)
