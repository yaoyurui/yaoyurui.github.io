"""NVIDIA adapter tests use dummy credentials and simulated HTTP, never real inference."""
import contextlib
import io
import json
import os
import sys
import unittest
import urllib.error
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import connect_nvidia as launcher
import rag_service
from test_rag import fixture_answer


class Response:
    def __init__(self, value): self.value = value
    def __enter__(self): return self
    def __exit__(self, *args): pass
    def read(self, n): return json.dumps(self.value).encode()


class NvidiaTests(unittest.TestCase):
    def test_only_verified_model_selected_no_deprecated_fallback(self):
        model = launcher.PREFERRED_MODELS[0]
        self.assertEqual(launcher.select_model([model]), model)
        self.assertIsNone(launcher.select_model(['nvidia/nemotron-3-nano-30b-a3b', 'nvidia/nv-embedqa-e5-v5']))

    def test_launcher_key_only_in_child_environment_and_catalog_not_auth(self):
        output = io.StringIO()
        secret = 'nvapi-dummy-NOT-A-REAL-KEY'
        with contextlib.redirect_stdout(output), patch.dict(os.environ, {'RAG_LAUNCH_KEY':secret}), \
             patch.object(launcher, 'available_models', return_value=list(launcher.PREFERRED_MODELS)) as models, \
             patch.object(launcher, 'diagnostic') as diagnostic, \
             patch.object(launcher, 'free_port', return_value=8838), \
             patch.object(launcher.subprocess, 'run', return_value=SimpleNamespace(returncode=0)) as run:
            self.assertEqual(launcher.main(), 0)
            self.assertNotIn('RAG_LAUNCH_KEY', os.environ)
        models.assert_called_once_with()  # Public catalog is not sent the key.
        args, kwargs = run.call_args
        self.assertEqual(kwargs['env']['RAG_MODEL_URL'], launcher.ENDPOINT)
        self.assertEqual(kwargs['env']['RAG_MODEL_NAME'], launcher.PREFERRED_MODELS[0])
        self.assertEqual(kwargs['env']['RAG_API_KEY'], secret)
        self.assertNotIn('RAG_LAUNCH_KEY', kwargs['env'])
        self.assertNotIn(secret, output.getvalue() + ' '.join(args[0]) + str(diagnostic.call_args))
        record = diagnostic.call_args.args[0]
        self.assertEqual(record['status'], 'catalog_accessible')
        self.assertFalse(record['authentication_verified'])
        self.assertFalse(record['generation_verified'])

    def test_empty_key_no_network(self):
        with contextlib.redirect_stdout(io.StringIO()), patch.dict(os.environ, {'RAG_LAUNCH_KEY':''}), \
             patch.object(launcher, 'diagnostic'), patch.object(launcher, 'available_models') as models:
            self.assertEqual(launcher.main(), 1)
        models.assert_not_called()

    def test_public_catalog_has_no_authorization_or_body(self):
        requests = []
        class Opener:
            def open(self, request, timeout):
                requests.append(request)
                return Response({'data':[{'id':launcher.PREFERRED_MODELS[0]},
                    {'id':'old/model','active':False}, {'id':'bad\nvalue'}]})
        with patch.object(launcher.urllib.request, 'build_opener', return_value=Opener()):
            self.assertEqual(launcher.available_models(), list(launcher.PREFERRED_MODELS))
        self.assertEqual(requests[0].full_url, launcher.MODELS_URL)
        self.assertIsNone(requests[0].get_header('Authorization'))
        self.assertIsNone(requests[0].data)

    def test_unavailable_model_does_not_start_or_silently_switch(self):
        with contextlib.redirect_stdout(io.StringIO()), patch.dict(os.environ, {'RAG_LAUNCH_KEY':'nvapi-dummy'}), \
             patch.object(launcher, 'available_models', return_value=['openai/gpt-oss-20b']), \
             patch.object(launcher, 'diagnostic'), patch.object(launcher.subprocess, 'run') as run:
            self.assertEqual(launcher.main(), 1)
        run.assert_not_called()

    def test_catalog_error_redacts_secret(self):
        secret = 'nvapi-dummy-secret-12345678901234567890'
        error = urllib.error.HTTPError(launcher.MODELS_URL, 403, 'Forbidden', {},
            io.BytesIO(json.dumps({'error':{'message':'Forbidden ' + secret}}).encode()))
        output = io.StringIO()
        with contextlib.redirect_stdout(output), patch.dict(os.environ, {'RAG_LAUNCH_KEY':secret}), \
             patch.object(launcher, 'available_models', side_effect=error), \
             patch.object(launcher, 'diagnostic') as diagnostic, patch.object(launcher.subprocess, 'run') as run:
            self.assertEqual(launcher.main(), 1)
        run.assert_not_called()
        self.assertNotIn(secret, output.getvalue() + str(diagnostic.call_args))

    def settings(self, endpoint=None):
        return {'endpoint':endpoint or launcher.ENDPOINT, 'model':launcher.PREFERRED_MODELS[0],
                'key':'nvapi-dummy', 'local':False, 'json_mode':True, 'timeout':10}

    def test_nvidia_request_and_exact_citations(self):
        settings = self.settings()
        sources = [{'ref':'R1','excerpt':'模拟规则原文：必须人工核查原始图像。'}]
        requests = []
        class Opener:
            def open(self, request, timeout):
                requests.append(request)
                return Response({'model':launcher.PREFERRED_MODELS[0], 'choices':[{'finish_reason':'stop',
                    'message':{'content':json.dumps(fixture_answer(sources))}}]})
        with patch.object(rag_service.urllib.request, 'build_opener', return_value=Opener()):
            answer = rag_service.call_model({'sample_id':'SIM-025'}, sources, [], settings)
        request = requests[0]
        self.assertEqual(request.full_url, launcher.ENDPOINT)
        self.assertEqual(request.get_header('Authorization'), 'Bearer nvapi-dummy')
        body = json.loads(request.data)
        self.assertEqual(body['model'], launcher.PREFERRED_MODELS[0])
        self.assertEqual(body['chat_template_kwargs'], {'enable_thinking':False})
        self.assertEqual(body['response_format'], {'type':'json_object'})
        self.assertEqual(body['max_tokens'], 4096)
        self.assertFalse(body['stream'])
        for field in ('max_completion_tokens','reasoning_effort','provider','thinking','models','plugins'):
            self.assertNotIn(field, body)
        rag_service.validate_answer(answer, sources, [])
        self.assertEqual(settings['resolved_model'], launcher.PREFERRED_MODELS[0])

    def test_nvidia_switch_not_sent_to_other_host(self):
        settings = self.settings('https://another-provider.example/v1/chat/completions')
        sources = [{'ref':'R1','excerpt':'模拟规则原文：必须人工核查原始图像。'}]
        class Opener:
            def open(inner, request, timeout):
                self.assertNotIn('chat_template_kwargs', json.loads(request.data))
                return Response({'choices':[{'message':{'content':json.dumps(fixture_answer(sources))}}]})
        with patch.object(rag_service.urllib.request, 'build_opener', return_value=Opener()):
            rag_service.call_model({}, sources, [], settings)

    def test_invalid_key_not_retried_or_replaced_with_template(self):
        settings = self.settings()
        class Opener:
            def open(self, request, timeout):
                raise urllib.error.HTTPError(launcher.ENDPOINT, 401, 'Unauthorized', {},
                    io.BytesIO(b'{"error":{"message":"bad key"}}'))
        with patch.object(rag_service.urllib.request, 'build_opener', return_value=Opener()):
            with self.assertRaises(rag_service.ModelHTTPError) as caught:
                rag_service.call_model({}, [], [], settings)
        self.assertEqual(caught.exception.status, 401)
        self.assertEqual(settings['request_options']['attempts'], 1)

    def test_public_status_does_not_leak_key_or_claim_inference_verified(self):
        with patch.dict(os.environ, {'RAG_MODEL_URL':launcher.ENDPOINT,
            'RAG_MODEL_NAME':launcher.PREFERRED_MODELS[0], 'RAG_API_KEY':'nvapi-dummy-secret'}):
            public = rag_service.public_config()
        self.assertTrue(public['configured'])
        self.assertIn('目录可见不代表密钥或生成已验证', public['service_notice'])
        self.assertNotIn('nvapi-dummy-secret', json.dumps(public))


if __name__ == '__main__': unittest.main(verbosity=2)
