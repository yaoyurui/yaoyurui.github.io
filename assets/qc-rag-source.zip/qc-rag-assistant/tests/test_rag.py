"""Offline tests. Fake provider responses below are fixtures, NOT model generations."""
import copy
import csv
import io
import json
import os
import shutil
import socket
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import app
from quality_rules import QualityService, RuleError
from rag_service import RagService, config, validate_answer


def fixture_answer(sources, conflicts=()):
    def evidence(s):
        return {"ref": s["ref"], "quote": s["excerpt"][:40]}
    return {"dispute": "模拟接口返回：两版记录存在分类分歧，需要人工核查。",
            "distinctions": [{"text": "模拟接口返回：请按所引原文区分两种情况。", "evidence": [evidence(sources[0])]}],
            "information_needed": [{"text": "模拟接口返回：还需核查原图与实物证据。", "evidence": []}],
            "review_steps": [{"text": "模拟接口返回：人工核对原文与现场记录。", "evidence": [evidence(sources[0])]}],
            "conflicts": [{"text": "模拟接口返回：双方对同一环节的约定存在冲突。",
                           "evidence": [evidence(sources[0]), evidence(sources[1])]}] if conflicts else []}


class Provider(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def do_POST(self):
        self.server.calls += 1
        data = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        self.server.last_request = data
        request = json.loads(data["messages"][1]["content"])
        answer = fixture_answer(request["evidence"], request["supplied_conflicts"])
        mode = self.server.mode
        if mode == "slow":
            threading.Event().wait(1.5)
        if mode == "unknown_reference":
            answer["distinctions"][0]["evidence"][0]["ref"] = "R99"
        if mode == "wrong_quote":
            answer["review_steps"][0]["evidence"][0]["quote"] = "不存在的质检标准原文不能被引用"
        if mode == "missing_conflict":
            answer["conflicts"] = []
        if mode in ("json_reject_once", "unknown_model", "thinking_rejected"):
            reject_json = mode == "json_reject_once" and "response_format" in data
            if reject_json or mode != "json_reject_once":
                messages = {"json_reject_once": "This response_format type is unavailable now",
                            "unknown_model": "Model Not Exist",
                            "thinking_rejected": "Invalid thinking options type"}
                raw = json.dumps({"error": {"message": messages[mode] + " private-do-not-expose",
                                           "code": "invalid_request_error"}}).encode()
                self.send_response(400)
                self.send_header("Content-Length", str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)
                return
        status = 503 if mode == "failure" else 200
        if mode == "redirect":
            self.send_response(302)
            self.send_header("Location", "https://example.invalid/collect")
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        content = json.dumps({"choices": [{"finish_reason": "stop", "message": {
            "content": "not json" if mode == "invalid_json" else json.dumps(answer, ensure_ascii=False)}}]}).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(content)))
        self.end_headers()
        try:
            self.wfile.write(content)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            pass


class RagTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        shutil.copytree(ROOT / "standards", self.root / "standards")
        self.quality = QualityService(self.root)
        self.rag = RagService(self.quality)
        self.quality.rag = self.rag
        self.result = app.demo_result()
        self.cid = self.quality.register(self.result)
        self.provider = ThreadingHTTPServer(("127.0.0.1", 0), Provider)
        self.provider.mode, self.provider.calls = "ok", 0
        threading.Thread(target=self.provider.serve_forever, daemon=True).start()
        env = {"RAG_MODEL_URL": f"http://127.0.0.1:{self.provider.server_port}/v1/chat/completions",
               "RAG_MODEL_NAME": "fake-provider-test-fixture", "RAG_API_KEY": "", "RAG_TIMEOUT_SECONDS": "2", "RAG_JSON_MODE": "1"}
        self.env = patch.dict(os.environ, env)
        self.env.start()

    def tearDown(self):
        self.env.stop()
        self.provider.shutdown()
        self.provider.server_close()
        self.temp.cleanup()

    def payload(self, **changes):
        value = {"comparison_id": self.cid, "sample_id": "SIM-025", "product": "演示电视A",
                 "part": "屏幕表面", "observations": "模拟资料，没有图像；只有标签分歧，需要核实原图。",
                 "query": "划痕 脏污", "send_confirmed": True}
        value.update(changes)
        return value

    def test_success_calls_http_model_and_persists(self):
        run = self.rag.run(self.payload())
        self.assertEqual(run["status"], "ok")
        self.assertEqual(self.provider.calls, 1)
        self.assertTrue(run["answer"]["dispute"].startswith("模拟接口返回"))
        self.assertFalse(run["context"]["has_image"])
        self.assertEqual(self.rag.get(run["run_id"]), run)
        self.assertEqual(self.rag.history(self.cid, "SIM-025")[0], run)
        request = self.provider.last_request
        self.assertEqual(request["model"], "fake-provider-test-fixture")
        self.assertEqual(request["response_format"], {"type": "json_object"})
        self.assertNotIn("base64", json.dumps(request))

    def test_missing_config_retains_sources_no_answer(self):
        with patch.dict(os.environ, {"RAG_MODEL_URL": "", "RAG_MODEL_NAME": ""}):
            run = self.rag.run(self.payload())
        self.assertEqual(run["status"], "not_configured")
        self.assertTrue(run["sources"])
        self.assertIsNone(run["answer"])
        self.assertEqual(self.provider.calls, 0)

    def test_label_only_needs_information_no_call(self):
        run = self.rag.run(self.payload(part="", observations=""))
        self.assertEqual(run["status"], "needs_information")
        self.assertTrue(run["sources"])
        self.assertEqual(self.provider.calls, 0)

    def test_no_product_needs_information(self):
        self.assertEqual(self.rag.run(self.payload(product=""))["status"], "needs_information")
        self.assertEqual(self.provider.calls, 0)

    def test_unknown_product_no_fallback(self):
        run = self.rag.run(self.payload(product="未导入产品"))
        self.assertEqual(run["status"], "no_match")
        self.assertEqual(run["sources"], [])

    def test_nonexistent_version_no_call(self):
        self.assertEqual(self.rag.run(self.payload(version="v999"))["status"], "no_match")
        self.assertEqual(self.provider.calls, 0)

    def test_wrong_part_no_call(self):
        self.assertEqual(self.rag.run(self.payload(part="后壳内部"))["status"], "no_match")
        self.assertEqual(self.provider.calls, 0)

    def test_no_matching_rule_no_model(self):
        run = self.rag.run(self.payload(query="火星量子xyz789"))
        self.assertEqual(run["status"], "no_match")
        self.assertIsNone(run["answer"])

    def test_product_b_only(self):
        run = self.rag.run(self.payload(product="演示电视B"))
        self.assertEqual(run["status"], "ok")
        self.assertTrue(all(s["product"] == "演示电视B" for s in run["sources"]))

    def test_explicit_version(self):
        run = self.rag.run(self.payload(version="v1.0", include_history=True))
        self.assertEqual(run["status"], "ok")
        self.assertTrue(all(s["version"] == "v1.0" for s in run["sources"]))
        self.assertTrue(any("历史" in w for w in run["warnings"]))

    def test_send_consent_required(self):
        self.assertEqual(self.rag.run(self.payload(send_confirmed=False))["status"], "consent_required")
        self.assertEqual(self.provider.calls, 0)

    def test_http_failure_preserves_sources(self):
        self.provider.mode = "failure"
        run = self.rag.run(self.payload())
        self.assertEqual(run["status"], "model_error")
        self.assertTrue(run["sources"])
        self.assertIsNone(run["answer"])

    def test_json_parameter_rejected_retries_without_it(self):
        self.provider.mode = "json_reject_once"
        run = self.rag.run(self.payload())
        self.assertEqual(run["status"], "ok")
        self.assertEqual(self.provider.calls, 2)
        self.assertNotIn("response_format", self.provider.last_request)
        self.assertEqual(run["model_request"]["attempts"], 2)
        self.assertFalse(run["model_request"]["json_mode"])
        self.assertTrue(any("重试" in s for s in run["warnings"]))

    def test_model_unavailable_error_is_classified_without_body(self):
        self.provider.mode = "unknown_model"
        run = self.rag.run(self.payload())
        self.assertEqual(run["status"], "model_error")
        self.assertEqual(run["provider_error"]["category"], "model_unavailable")
        self.assertEqual(self.provider.calls, 1)
        self.assertNotIn("private-do-not-expose", json.dumps(run))

    def test_thinking_error_classified_no_retry(self):
        self.provider.mode = "thinking_rejected"
        run = self.rag.run(self.payload())
        self.assertEqual(run["provider_error"]["category"], "thinking_parameters")
        self.assertEqual(self.provider.calls, 1)

    def test_deepseek_request_disables_thinking_only_on_its_host(self):
        import rag_service
        settings = config()
        settings.update(endpoint="https://api.deepseek.com/chat/completions", model="deepseek-flash", key="dummy-key")
        run = self.rag.run(self.payload())
        sources = run["sources"]
        fake = json.dumps({"choices": [{"finish_reason": "stop", "message": {
            "content": json.dumps(fixture_answer(sources))}}]}).encode()
        class Response:
            def __enter__(self): return self
            def __exit__(self, *args): pass
            def read(self, n): return fake
        class Opener:
            def open(inner, req, timeout):
                body = json.loads(req.data)
                self.assertEqual(body["thinking"], {"type": "disabled"})
                self.assertEqual(body["max_tokens"], 4096)
                return Response()
        with patch.object(rag_service.urllib.request, "build_opener", return_value=Opener()):
            rag_service.call_model({}, sources, [], settings)
        self.assertEqual(settings["request_options"]["thinking"], "disabled")

    def test_timeout_preserves_sources(self):
        with patch("rag_service.call_model", side_effect=socket.timeout):
            run = self.rag.run(self.payload())
        self.assertEqual(run["status"], "timeout")
        self.assertTrue(run["sources"])

    def test_real_http_timeout_preserves_sources(self):
        self.provider.mode = "slow"
        with patch.dict(os.environ, {"RAG_TIMEOUT_SECONDS": "1"}):
            run = self.rag.run(self.payload())
        self.assertEqual(run["status"], "timeout")
        self.assertTrue(run["sources"])
        self.assertEqual(self.provider.calls, 1)

    def test_invalid_reference_hidden(self):
        self.provider.mode = "unknown_reference"
        run = self.rag.run(self.payload())
        self.assertEqual(run["status"], "invalid_answer")
        self.assertIsNone(run["answer"])

    def test_non_verbatim_quote_hidden(self):
        self.provider.mode = "wrong_quote"
        self.assertEqual(self.rag.run(self.payload())["status"], "invalid_answer")

    def test_bad_json_hidden(self):
        self.provider.mode = "invalid_json"
        self.assertEqual(self.rag.run(self.payload())["status"], "invalid_answer")

    def test_redirect_not_followed(self):
        self.provider.mode = "redirect"
        self.assertEqual(self.rag.run(self.payload())["status"], "model_error")
        self.assertEqual(self.provider.calls, 1)

    def test_conflict_both_sides(self):
        run = self.rag.run(self.payload(product="演示冲突电视", query="脏污 清洁 复拍"))
        self.assertEqual(run["status"], "ok")
        self.assertTrue(run["conflicts"])
        self.assertEqual(len(run["answer"]["conflicts"][0]["evidence"]), 2)

    def test_omitted_conflict_rejected(self):
        self.provider.mode = "missing_conflict"
        run = self.rag.run(self.payload(product="演示冲突电视", query="脏污 清洁 复拍"))
        self.assertEqual(run["status"], "invalid_answer")
        self.assertTrue(run["conflicts"])

    def test_review_links_run_and_export_unchanged_stats(self):
        baseline = copy.deepcopy(self.quality.comparison(self.cid))
        run = self.rag.run(self.payload())
        c = run["sources"][0]
        self.quality.save_review({"comparison_id": self.cid, "sample_id": "SIM-025", "product": "演示电视A",
            "reviewer": "自动验证（模拟）", "note": "非真实试用", "rag_run_id": run["run_id"], "citations": [c]})
        stored = self.quality.reviews(self.cid)["SIM-025"]
        self.assertEqual(stored["rag"]["run_id"], run["run_id"])
        exported = list(csv.reader(io.StringIO(app.csv_text(self.result, {"SIM-025": stored}))))
        row = next(r for r in exported[1:] if r[0] == "SIM-025")
        self.assertEqual(row[15], run["run_id"])
        self.assertIn("模拟接口返回", row[17])
        after = self.quality.comparison(self.cid)
        self.assertEqual(baseline["counts"], after["counts"])
        self.assertEqual(baseline["rows"], after["rows"])
        self.assertEqual(after["comparable"], 22)

    def test_cross_sample_run_link_rejected(self):
        run = self.rag.run(self.payload())
        with self.assertRaises(RuleError):
            self.quality.save_review({"comparison_id": self.cid, "sample_id": "SIM-023", "product": "演示电视A",
                                     "reviewer": "模拟", "rag_run_id": run["run_id"]})

    def test_metadata_missing_marked_not_invented(self):
        target = self.root / "standards" / "plain.md"
        target.write_text("# 观察要求\n模拟规则：证据不足时应由人工保持待确认。\n", encoding="utf-8")
        catalog = self.root / "standards" / "catalog.json"
        docs = json.loads(catalog.read_text(encoding="utf-8"))
        docs.append({"id": "PLAIN", "source_file": "plain.md"})
        catalog.write_text(json.dumps(docs, ensure_ascii=False), encoding="utf-8")
        d = next(d for d in self.quality.documents() if d["id"] == "PLAIN")
        self.assertEqual(d["version"], "未提供")
        self.assertEqual(d["product"], "未提供")
        c = self.quality.citation(d, d["clauses"][0])
        self.assertEqual(c["clause_id"], "未提供")
        self.assertEqual(c["page"], "未提供")
        self.assertIn("观察要求", c["location"])

    def test_long_chunk_locations_and_unique_ids(self):
        from standard_parser import split_clauses
        text = "[LONG] 模拟长标准\n" + "标准原文测试" * 1500
        chunks = split_clauses(text)
        self.assertGreater(len(chunks), 2)
        self.assertTrue(all(len(c["text"]) <= 1600 for c in chunks))
        self.assertEqual(len({c["chunk_id"] for c in chunks}), len(chunks))
        self.assertTrue(all(c["end_line"] == 2 for c in chunks))

    def test_docx_parser(self):
        from standard_parser import parse_source
        path = self.root / "standards" / "demo.docx"
        with zipfile.ZipFile(path, "w") as archive:
            archive.writestr("word/document.xml", '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:r><w:t>[X] 模拟标准</w:t></w:r></w:p><w:p><w:r><w:t>人工核对原始图像，不自动判定。</w:t></w:r></w:p></w:body></w:document>')
        text, kind = parse_source(path)
        self.assertIn("人工核对", text)
        self.assertIn("非页码", kind)

    def test_import_context_preserved_counts_unchanged(self):
        header = ["样本编号", "人工标签", "模型预测结果", "产品", "部位", "现场观察"]
        a = app.normalize([header, ["001", "划痕", "划痕", "电视A", "屏幕", "待核查"]], "旧")
        b = app.normalize([header, ["001", "划痕", "脏污", "电视A", "屏幕", "待核查"]], "新")
        result = app.compare(a, b)
        self.assertEqual(result["counts"]["新增错误"], 1)
        self.assertEqual(result["rows"][0]["inspection_context"]["new_product"], "电视A")

    def test_config_rejects_http_external_no_secret(self):
        with patch.dict(os.environ, {"RAG_MODEL_URL": "http://example.invalid/v1/chat/completions", "RAG_API_KEY": "secret-fixture"}):
            self.assertFalse(config()["configured"])


class RagApiTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.env = patch.dict(os.environ, {"QC_REVIEW_DATA_DIR": self.temp.name, "RAG_MODEL_URL": "", "RAG_MODEL_NAME": "", "RAG_API_KEY": ""})
        self.env.start()
        self.server = app.LocalServer(("127.0.0.1", 0), app.Handler)
        threading.Thread(target=self.server.serve_forever, daemon=True).start()
        self.base = f"http://127.0.0.1:{self.server.server_port}"
        self.opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.env.stop()
        self.temp.cleanup()

    def fetch(self, path, body=None, origin=None):
        req = urllib.request.Request(self.base+path, data=json.dumps(body).encode() if body is not None else None,
            headers={"Content-Type": "application/json", "Origin": origin or self.base})
        with self.opener.open(req, timeout=10) as r:
            return json.load(r)

    def test_rag_api_degraded_and_history(self):
        result = self.fetch("/api/demo")
        run = self.fetch("/api/rag/run", {"comparison_id": result["comparison_id"], "sample_id": "SIM-025",
            "product": "演示电视A", "part": "屏幕表面", "observations": "模拟，无图像", "query": "划痕 脏污"})
        self.assertEqual(run["status"], "not_configured")
        history = self.fetch("/api/rag/history?comparison_id="+result["comparison_id"]+"&sample_id=SIM-025")
        self.assertEqual(history["history"][0]["run_id"], run["run_id"])
        self.assertEqual(self.fetch("/api/demo")["counts"], result["counts"])

    def test_no_api_key_exposed(self):
        with patch.dict(os.environ, {"RAG_API_KEY": "never-expose-fixture"}):
            data = self.fetch("/api/rag/status")
        self.assertNotIn("never-expose", json.dumps(data))
        self.assertNotIn("key", data)

    def test_cross_origin_rag_blocked(self):
        with self.assertRaises(urllib.error.HTTPError) as caught:
            self.fetch("/api/rag/run", {}, "https://example.invalid")
        self.assertEqual(caught.exception.code, 403)


if __name__ == "__main__":
    unittest.main(verbosity=2)
