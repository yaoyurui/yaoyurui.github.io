"""Real Windows DPAPI tests, isolated temporary roots, fake keys only; no network."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from connect_deepseek import windows_dialog


@unittest.skipUnless(os.name=='nt','Windows DPAPI only')
class CredentialTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        executable=Path(os.environ.get('SystemRoot',r'C:\Windows'))/'System32/WindowsPowerShell/v1.0/powershell.exe'
        probe="Add-Type -AssemblyName System.Security; try {$b=[Text.Encoding]::UTF8.GetBytes('dummy-probe'); [void][Security.Cryptography.ProtectedData]::Protect($b,$null,[Security.Cryptography.DataProtectionScope]::CurrentUser); exit 0} catch {exit 42}"
        result=subprocess.run([str(executable),'-NoProfile','-Command',probe],capture_output=True,timeout=15)
        if result.returncode!=0:
            raise unittest.SkipTest('Current restricted process has no loaded Windows DPAPI user profile; run 密钥加密自检.cmd from Explorer to verify real encryption')

    def setUp(self):
        self.temporary=tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root=Path(self.temporary.name)
        self.library=(ROOT/'windows_credential_store.ps1').read_text(encoding='utf-8-sig')

    def ps(self,script):
        environment=os.environ.copy()
        environment['RAG_TEST_ROOT']=str(self.root)
        executable=Path(os.environ.get('SystemRoot',r'C:\Windows'))/'System32/WindowsPowerShell/v1.0/powershell.exe'
        result=subprocess.run([str(executable),'-NoProfile','-Command',
            "$ErrorActionPreference='Stop'\n"+self.library+'\n'+script],
            env=environment,capture_output=True,timeout=25)
        self.assertEqual(result.returncode,0,result.stderr.decode(errors='replace'))
        return result

    def save(self):
        self.ps("$s=New-RagSecureString 'dummy-id.fake-only-never-real'; Save-RagCredential $env:RAG_TEST_ROOT $s; $s.Dispose()")

    def test_cross_process_saved_value_roundtrip_no_plaintext_file(self):
        self.save()
        saved=self.root/'data/credentials/bigmodel.current-user.dpapi'
        self.assertTrue(saved.exists())
        raw=saved.read_bytes()
        self.assertNotIn(b'dummy-id.fake-only-never-real',raw)
        self.assertNotIn('dummy-id.fake-only-never-real'.encode('utf-16le'),raw)
        self.ps("$s=Read-RagCredential $env:RAG_TEST_ROOT; if ((Get-RagPlainKey $s) -ne 'dummy-id.fake-only-never-real') {throw 'Roundtrip failed'}; $s.Dispose()")

    def test_replace_and_clear_are_persistent_and_no_temporary_files_remain(self):
        self.save()
        self.ps("$s=New-RagSecureString 'dummy-id.replacement-only'; Save-RagCredential $env:RAG_TEST_ROOT $s; $s.Dispose()")
        self.ps("$s=Read-RagCredential $env:RAG_TEST_ROOT; if ((Get-RagPlainKey $s) -ne 'dummy-id.replacement-only') {throw 'Replace failed'}; $s.Dispose(); Clear-RagCredential $env:RAG_TEST_ROOT; Clear-RagCredential $env:RAG_TEST_ROOT; if ($null -ne (Read-RagCredential $env:RAG_TEST_ROOT)) {throw 'Clear failed'}")
        self.assertEqual(list((self.root/'data/credentials').iterdir()),[])

    def test_corrupt_ciphertext_fails_closed(self):
        self.save()
        p=self.root/'data/credentials/bigmodel.current-user.dpapi'
        p.write_text('not-a-valid-DPAPI-ciphertext',encoding='utf-8')
        self.ps("$rejected=$false; try {$s=Read-RagCredential $env:RAG_TEST_ROOT} catch {$rejected=$true}; if (-not $rejected) {throw 'Corrupt value accepted'}")

    def test_failed_save_keeps_previous_ciphertext(self):
        self.save()
        p=self.root/'data/credentials/bigmodel.current-user.dpapi'
        before=p.read_bytes()
        self.ps("function Protect-RagSecret {throw 'Simulated encryption failure'}; $s=New-RagSecureString 'dummy.other'; try {Save-RagCredential $env:RAG_TEST_ROOT $s} catch {}; $s.Dispose()")
        self.assertEqual(p.read_bytes(),before)

    def test_input_normalization_and_masked_rejection(self):
        self.ps('''
if ((Normalize-RagInput ' Bearer dummy-id.test-key ') -ne 'dummy-id.test-key') {throw 'Bearer failed'}
if ((Normalize-RagInput '"dummy-id.test-key"') -ne 'dummy-id.test-key') {throw 'Quotes failed'}
if (-not (Test-RagInput 'dummy-id.test-key')) {throw 'Good input rejected'}
foreach ($v in @('', 'dummy.***', 'dummy...key', 'dummy key')) {
    if (Test-RagInput $v) {throw 'Bad input accepted'}
}
''')

    def test_saved_key_autoloads_into_backend_without_dialog_or_printing_secret(self):
        self.save()
        child=self.root/'fake_backend.py'
        child.write_text("import os,json,pathlib\n"+
            "pathlib.Path(__file__).with_suffix('.json').write_text(json.dumps({"+
            "'key_correct':os.environ.get('RAG_LAUNCH_KEY')=='dummy-id.fake-only-never-real',"+
            "'source_saved':os.environ.get('RAG_KEY_SOURCE')=='saved'}))\n",encoding='utf-8')
        # Uses the actual launcher and PS autoload path, never the real user's vault.
        result=windows_dialog(launcher_file=child,provider='BigModel')
        self.assertEqual(result,0)
        self.assertEqual(json.loads(child.with_suffix('.json').read_text()),{'key_correct':True,'source_saved':True})

    def test_clear_entry_uses_app_root_and_does_not_launch_backend(self):
        self.save()
        child=self.root/'must_not_run.py'
        child.write_text("raise RuntimeError('Backend should not start')",encoding='utf-8')
        self.assertEqual(windows_dialog(launcher_file=child,provider='BigModel',mode='clear'),0)
        self.assertFalse((self.root/'data/credentials/bigmodel.current-user.dpapi').exists())


@unittest.skipUnless(os.name=='nt','Windows launcher only')
class CredentialFlowTests(CredentialTests):
    """I/O and startup flow with explicitly simulated crypto, not encryption proof."""
    @classmethod
    def setUpClass(cls): pass

    def ps(self,script):
        # Override cryptographic functions only inside this isolated TEST process.
        fake='''
function Protect-RagSecret([Security.SecureString]$Secret) {
    return [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes((Get-RagPlainKey $Secret)))
}
function Unprotect-RagSecret([string]$Cipher) {
    return New-RagSecureString ([Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($Cipher)))
}
'''
        return super().ps(fake+'\n'+script)

    def test_saved_key_autoloads_into_backend_without_dialog_or_printing_secret(self):
        child=self.root/'fake_backend.py'
        child.write_text("import os,json,pathlib\npathlib.Path(__file__).with_suffix('.json').write_text(json.dumps({'key_correct':os.environ.get('RAG_LAUNCH_KEY')=='dummy-id.fake-only-never-real','source_saved':os.environ.get('RAG_KEY_SOURCE')=='saved'}))\n",encoding='utf-8')
        fake="function Read-RagCredential([string]$AppRoot) {return New-RagSecureString 'dummy-id.fake-only-never-real'}\n"
        script=(ROOT/'windows_bigmodel_key_dialog.ps1').read_text(encoding='utf-8-sig')
        # Test the actual auto-start control flow with a fake credential reader.
        self.ps("$env:RAG_LAUNCH_SCRIPT="+"'"+str(child).replace("'","''")+"'; $env:RAG_PY='"+sys.executable.replace("'","''")+"'; $env:RAG_KEY_MODE='normal'; $env:RAG_DIALOG_SELF_TEST='0';\n"+fake+script)
        self.assertEqual(json.loads(child.with_suffix('.json').read_text()),{'key_correct':True,'source_saved':True})

    def test_clear_entry_uses_app_root_and_does_not_launch_backend(self):
        self.save()
        script=(ROOT/'windows_bigmodel_key_dialog.ps1').read_text(encoding='utf-8-sig')
        child=self.root/'must_not_run.py'
        self.ps("$env:RAG_LAUNCH_SCRIPT='"+str(child).replace("'","''")+"'; $env:RAG_KEY_MODE='clear'; $env:RAG_DIALOG_SELF_TEST='0';\n"+script)
        self.assertFalse((self.root/'data/credentials/bigmodel.current-user.dpapi').exists())


if __name__=='__main__':unittest.main(verbosity=2)
