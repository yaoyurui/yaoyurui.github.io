"""Launcher tests use a dummy key and mocked child process; no real API calls."""
import contextlib
import io
import os
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import connect_deepseek as launcher


class LauncherTests(unittest.TestCase):
    def setUp(self):
        diagnostic = patch.object(launcher, "save_diagnostic")
        self.diagnostic = diagnostic.start()
        self.addCleanup(diagnostic.stop)

    def test_key_goes_to_child_environment_only(self):
        output = io.StringIO()
        old = os.environ.get("RAG_API_KEY")
        with contextlib.redirect_stdout(output), patch.object(launcher.getpass, "getpass", return_value="dummy-local-test-key"), \
             patch.object(launcher, "available_models", return_value=["deepseek-flash"]), \
             patch.object(launcher, "free_port", return_value=8838), \
             patch.object(launcher.subprocess, "run", return_value=SimpleNamespace(returncode=0)) as run:
            self.assertEqual(launcher.main(), 0)
        args, kwargs = run.call_args
        self.assertEqual(args[0][-1], "8838")
        self.assertEqual(kwargs["env"]["RAG_API_KEY"], "dummy-local-test-key")
        self.assertEqual(kwargs["env"]["RAG_MODEL_NAME"], "deepseek-flash")
        self.assertNotIn("dummy-local-test-key", output.getvalue())
        self.assertNotIn("dummy-local-test-key", " ".join(args[0]))
        self.assertEqual(os.environ.get("RAG_API_KEY"), old)

    def test_empty_key_does_not_launch(self):
        with contextlib.redirect_stdout(io.StringIO()), patch.object(launcher.getpass, "getpass", return_value=""), \
             patch.object(launcher.subprocess, "run") as run:
            self.assertEqual(launcher.main(), 1)
        run.assert_not_called()

    def test_masked_key_is_rejected_before_network(self):
        with contextlib.redirect_stdout(io.StringIO()), patch.object(launcher.getpass, "getpass", return_value="sk-*******"), \
             patch.object(launcher, "available_models") as models:
            self.assertEqual(launcher.main(), 1)
        models.assert_not_called()

    def test_free_port_is_in_expected_range(self):
        self.assertIn(launcher.free_port(), range(8790, 8840))

    def test_select_model_must_exist_in_account(self):
        self.assertEqual(launcher.select_model(["deepseek-chat", "deepseek-reasoner"]), "deepseek-chat")
        self.assertEqual(launcher.select_model(["deepseek-v4-pro", "deepseek-flash"]), "deepseek-flash")

    def test_actual_account_model_passed_to_backend(self):
        output = io.StringIO()
        with contextlib.redirect_stdout(output), patch.object(launcher.getpass, "getpass", return_value="dummy-key"), \
             patch.object(launcher, "available_models", return_value=["deepseek-chat"]), \
             patch.object(launcher, "free_port", return_value=8838), \
             patch.object(launcher.subprocess, "run", return_value=SimpleNamespace(returncode=0)) as run:
            self.assertEqual(launcher.main(), 0)
        self.assertEqual(run.call_args.kwargs["env"]["RAG_MODEL_NAME"], "deepseek-chat")
        self.assertIn("deepseek-chat", output.getvalue())
        self.assertNotIn("dummy-key", output.getvalue())

    def test_models_failure_does_not_start_backend(self):
        with contextlib.redirect_stdout(io.StringIO()), patch.object(launcher.getpass, "getpass", return_value="dummy-key"), \
             patch.object(launcher, "available_models", side_effect=ValueError("private-provider-error")), \
             patch.object(launcher.subprocess, "run") as run:
            self.assertEqual(launcher.main(), 1)
        run.assert_not_called()

    def test_ctrl_v_character_does_not_invalidate_complete_key(self):
        self.assertEqual(launcher.normalize_key('\x16sk-test-token-123\r\n'), 'sk-test-token-123')

    def test_paired_quotes_and_clipboard_edges(self):
        self.assertEqual(launcher.normalize_key('\ufeff"sk-test-token-123"\u200b'), 'sk-test-token-123')

    def test_bearer_prefix_is_removed(self):
        self.assertEqual(launcher.normalize_key('Bearer sk-test-token-123'), 'sk-test-token-123')

    def test_internal_newline_not_silently_joined(self):
        key = launcher.normalize_key('sk-one\nsk-two')
        self.assertEqual(launcher.key_input_error(key), 'whitespace')

    def test_input_failure_diagnostic_does_not_contain_key(self):
        value = 'sk-test secret'
        with contextlib.redirect_stdout(io.StringIO()), patch.object(launcher.getpass, 'getpass', return_value=value):
            self.assertEqual(launcher.main(), 1)
        diagnostic = self.diagnostic.call_args.args[0]
        self.assertEqual(diagnostic['reason_kind'], 'whitespace')
        self.assertFalse(diagnostic['network_request_sent'])
        self.assertNotIn(value, str(diagnostic))

    def test_native_secret_consumed_and_not_forwarded_twice(self):
        output = io.StringIO()
        with contextlib.redirect_stdout(output), patch.dict(os.environ, {'RAG_LAUNCH_KEY':'sk-native-dummy-key'}), \
             patch.object(launcher.getpass, 'getpass') as getpass, \
             patch.object(launcher, 'available_models', return_value=['deepseek-chat']), \
             patch.object(launcher, 'free_port', return_value=8838), \
             patch.object(launcher.subprocess, 'run', return_value=SimpleNamespace(returncode=0)) as run:
            self.assertEqual(launcher.main(), 0)
            self.assertNotIn('RAG_LAUNCH_KEY', os.environ)
        getpass.assert_not_called()
        self.assertNotIn('RAG_LAUNCH_KEY', run.call_args.kwargs['env'])
        self.assertEqual(run.call_args.kwargs['env']['RAG_API_KEY'], 'sk-native-dummy-key')
        self.assertNotIn('sk-native-dummy-key', output.getvalue())

    def test_valid_ascii_token_not_over_restricted(self):
        self.assertEqual(launcher.key_input_error('sk-valid-secret-token'), '')


if __name__ == "__main__":
    unittest.main(verbosity=2)
