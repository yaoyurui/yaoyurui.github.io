"""Groq wiring tests; fake credentials and HTTP, no real inference."""
import contextlib
import io
import json
import os
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import connect_groq as launcher
import rag_service
from test_rag import fixture_answer


class Response:
    def __init__(self, value): self.value = value
    def __enter__(self): return self
    def __exit__(self, *args): pass
    def read(self, n): return json.dumps(self.value).encode()


class GroqTests(unittest.TestCase):
    def test_model_preference_uses_returned_models_only(self):
        self.assertEqual(launcher.select_model(['openai/gpt-oss-120b','openai/gpt-oss-20b']), 'openai/gpt-oss-20b')
        self.assertEqual(launcher.select_model(['qwen/qwen3.8-27b']), 'qwen/qwen3.8-27b')
        self.assertIsNone(launcher.select_model(['whisper-large-v3']))

    def test_launcher_sets_groq_and_keeps_key_private(self):
        output = io.StringIO()
        with contextlib.redirect_stdout(output), patch.dict(os.environ, {'RAG_LAUNCH_KEY':'gsk_dummy_secret'}), \
             patch.object(launcher, 'available_models', return_value=['openai/gpt-oss-20b']), \
             patch.object(launcher, 'diagnostic') as diagnostic, \
             patch.object(launcher, 'free_port', return_value=8838), \
             patch.object(launcher.subprocess, 'run', return_value=SimpleNamespace(returncode=0)) as run:
            self.assertEqual(launcher.main(), 0)
        env = run.call_args.kwargs['env']
        self.assertEqual(env['RAG_MODEL_URL'], launcher.ENDPOINT)
        self.assertEqual(env['RAG_MODEL_NAME'], 'openai/gpt-oss-20b')
        self.assertNotIn('RAG_LAUNCH_KEY', env)
        self.assertNotIn('gsk_dummy_secret', output.getvalue())
        self.assertFalse(diagnostic.call_args.args[0]['generation_verified'])

    def test_empty_key_no_request(self):
        with contextlib.redirect_stdout(io.StringIO()), patch.dict(os.environ, {'RAG_LAUNCH_KEY':''}), \
             patch.object(launcher, 'diagnostic'), patch.object(launcher, 'available_models') as models:
            self.assertEqual(launcher.main(), 1)
        models.assert_not_called()

    def test_model_list_filters_inactive(self):
        requests = []
        class Opener:
            def open(self, request, timeout):
                requests.append(request)
                return Response({'data':[{'id':'openai/gpt-oss-20b','active':True},
                    {'id':'old/model','active':False},{'id':'whisper-large-v3'}]})
        with patch.object(launcher.urllib.request, 'build_opener', return_value=Opener()):
            result = launcher.available_models('gsk_dummy')
        self.assertEqual(result, ['openai/gpt-oss-20b','whisper-large-v3'])
        self.assertEqual(requests[0].full_url, launcher.MODELS_URL)
        self.assertIsNone(requests[0].data)

    def test_no_text_model_blocks_start(self):
        with contextlib.redirect_stdout(io.StringIO()), patch.dict(os.environ, {'RAG_LAUNCH_KEY':'gsk_dummy'}), \
             patch.object(launcher, 'available_models', return_value=['whisper-large-v3']), \
             patch.object(launcher, 'diagnostic'), patch.object(launcher.subprocess, 'run') as run:
            self.assertEqual(launcher.main(), 1)
        run.assert_not_called()

    def test_groq_parameters_and_answer_validation(self):
        settings = {'endpoint':launcher.ENDPOINT,'model':'openai/gpt-oss-20b','key':'gsk_dummy',
                    'local':False,'json_mode':True,'timeout':10}
        sources = [{'ref':'R1','excerpt':'模拟规则原文：必须人工核查原始图像。'}]
        requests = []
        class Opener:
            def open(self, request, timeout):
                requests.append(request)
                return Response({'model':'openai/gpt-oss-20b','choices':[{'finish_reason':'stop',
                    'message':{'content':json.dumps(fixture_answer(sources))}}]})
        with patch.object(rag_service.urllib.request, 'build_opener', return_value=Opener()):
            answer = rag_service.call_model({}, sources, [], settings)
        body = json.loads(requests[0].data)
        self.assertEqual(body['max_completion_tokens'], 4096)
        self.assertEqual(body['reasoning_effort'], 'low')
        self.assertEqual(body['response_format'], {'type':'json_object'})
        for field in ('max_tokens','provider','thinking','models','service_tier','plugins'):
            self.assertNotIn(field, body)
        rag_service.validate_answer(answer, sources, [])

    def test_qwen_not_sent_gpt_specific_reasoning(self):
        settings = {'endpoint':launcher.ENDPOINT,'model':'qwen/qwen3.8-27b','key':'gsk_dummy',
                    'local':False,'json_mode':True,'timeout':10}
        sources = [{'ref':'R1','excerpt':'模拟规则原文：必须人工核查原始图像。'}]
        class Opener:
            def open(inner, request, timeout):
                self.assertNotIn('reasoning_effort', json.loads(request.data))
                return Response({'choices':[{'finish_reason':'stop','message':{'content':json.dumps(fixture_answer(sources))}}]})
        with patch.object(rag_service.urllib.request, 'build_opener', return_value=Opener()):
            rag_service.call_model({}, sources, [], settings)

    def test_public_config_does_not_claim_guaranteed_free(self):
        with patch.dict(os.environ, {'RAG_MODEL_URL':launcher.ENDPOINT,'RAG_MODEL_NAME':'openai/gpt-oss-20b',
                                     'RAG_API_KEY':'gsk_dummy_secret'}):
            public = rag_service.public_config()
        self.assertFalse(public['free_only'])
        self.assertIn('账号组织套餐', public['service_notice'])
        self.assertNotIn('gsk_dummy_secret', json.dumps(public))


if __name__ == '__main__': unittest.main(verbosity=2)
