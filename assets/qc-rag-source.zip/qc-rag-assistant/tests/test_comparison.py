import base64
import copy
import importlib.util
import io
import json
import sys
import unittest
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
spec=importlib.util.spec_from_file_location('version_app',ROOT/'app.py')
app=importlib.util.module_from_spec(spec)
spec.loader.exec_module(app)


class ComparisonTests(unittest.TestCase):
    def setUp(self):
        self.old,self.new=app.demo_matrices()

    def test_demo_independent_expected_statuses(self):
        result=app.demo_result()
        self.assertEqual(result['total'],30)
        self.assertEqual(result['comparable'],22)
        self.assertEqual(result['review'],8)
        expected={**{f'SIM-{n:03}':'已修复' for n in range(1,7)},
                  **{f'SIM-{n:03}':'新增错误' for n in range(7,11)},
                  **{f'SIM-{n:03}':'持续错误' for n in range(11,16)},
                  **{f'SIM-{n:03}':'保持正确' for n in range(16,23)},
                  'SIM-023':'标签待确认','SIM-024':'标签待确认','SIM-025':'标签已变更',
                  'SIM-026':'数据不完整','SIM-027':'数据不完整','SIM-028':'数据不完整',
                  'SIM-029':'仅旧版','SIM-030':'仅新版'}
        self.assertEqual({r['id']:r['status'] for r in result['rows']},expected)
        self.assertEqual(result['old_errors'],11)
        self.assertEqual(result['new_errors'],9)

    def test_changed_label_not_model_fix(self):
        a=app.normalize([self.old[0],['001','脏污','划痕','已确认']],'旧')
        b=app.normalize([self.old[0],['001','划痕','划痕','已确认']],'新')
        result=app.compare(a,b)
        self.assertEqual(result['counts']['标签已变更'],1)
        self.assertEqual(result['comparable'],0)
        self.assertIn('没有可比样本',result['summary'])

    def test_duplicate_blocked(self):
        with self.assertRaises(app.InputError):
            app.normalize([self.old[0],self.old[1],self.old[1]],'旧')

    def test_missing_id_blocked(self):
        with self.assertRaises(app.InputError):
            app.normalize([self.old[0],['','划痕','划痕','已确认']],'旧')

    def test_missing_required_column(self):
        with self.assertRaises(app.InputError):
            app.normalize([['样本编号','人工标签'],['001','划痕']],'旧')

    def test_formula_blocked(self):
        with self.assertRaises(app.InputError):
            app.normalize([self.old[0],['001','划痕',app.Formula(),'已确认']],'旧')

    def test_unknown_state_pending(self):
        a=app.normalize([self.old[0],['001','划痕','划痕','业务待判']],'旧')
        result=app.compare(a,a)
        self.assertEqual(result['counts']['标签待确认'],1)

    def test_reordered_samples_match_by_id(self):
        before=app.normalize(self.old,'旧')
        after=app.normalize([self.new[0]]+list(reversed(self.new[1:])),'新')
        self.assertEqual(app.compare(before,after)['counts'],app.demo_result()['counts'])

    def test_zero_label_not_missing(self):
        a=app.normalize([self.old[0],['001','0','0','已确认']],'旧')
        self.assertEqual(app.compare(a,a)['counts']['保持正确'],1)

    def test_csv_utf8_and_gb18030(self):
        import csv
        stream=io.StringIO()
        csv.writer(stream).writerows(self.old)
        for encoding in ['utf-8-sig','gb18030']:
            matrix,_=app.csv_matrix(stream.getvalue().encode(encoding))
            self.assertEqual(len(app.normalize(matrix,'旧')),29)

    def test_formula_injection_export_escaped(self):
        result=copy.deepcopy(app.demo_result())
        result['rows'][0]['id']='=HYPERLINK("test")'
        self.assertIn("'=HYPERLINK",app.csv_text(result))

    def test_malformed_xlsx(self):
        with self.assertRaises(app.InputError):
            app.xlsx_matrix(b'not-a-workbook')

    def test_excel_examples_roundtrip(self):
        rows=[]
        for name in ['模拟旧版.xlsx','模拟新版.xlsx']:
            data=(ROOT/'samples'/name).read_bytes()
            matrix,sheet=app.xlsx_matrix(data)
            self.assertEqual(sheet,'样本')
            rows.append(app.normalize(matrix,name))
        result=app.compare(*rows)
        self.assertEqual(result['counts'],app.demo_result()['counts'])

    def test_unknown_file_extension(self):
        with self.assertRaises(app.InputError):
            app.read_file({'name':'test.xls','data':base64.b64encode(b'abc').decode()},'旧')

    def test_blank_rows_ignored(self):
        records=app.normalize([self.old[0],[],self.old[1],['','','','']],'旧')
        self.assertEqual(len(records),1)


if __name__=='__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    unittest.main(verbosity=2)
