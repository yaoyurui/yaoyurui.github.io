"""Free-only OpenRouter wiring tests. Dummy keys and mocked HTTP only."""
import contextlib
import io
import json
import os
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import connect_openrouter as launcher
import rag_service
from test_rag import fixture_answer


class Response:
    def __init__(self, obj): self.obj = obj
    def __enter__(self): return self
    def __exit__(self, *args): pass
    def read(self, size): return json.dumps(self.obj).encode()


class OpenRouterTests(unittest.TestCase):
    def settings(self, model='openrouter/free'):
        return {'endpoint': launcher.ENDPOINT, 'model': model, 'key': 'sk-or-dummy-key', 'json_mode': True,
                'local': False, 'timeout': 10, 'free_only': True}

    def test_launcher_sets_free_router_not_deepseek(self):
        output = io.StringIO()
        with contextlib.redirect_stdout(output), patch.dict(os.environ, {'RAG_LAUNCH_KEY':'sk-or-dummy-secret','RAG_NETWORK_MODE':'direct'}), \
             patch.object(launcher, 'diagnostic') as diagnostic, \
             patch.object(launcher, 'check_key', return_value={'remaining': 50}), \
             patch.object(launcher, 'free_port', return_value=8838), \
             patch.object(launcher.subprocess, 'run', return_value=SimpleNamespace(returncode=0)) as run:
            self.assertEqual(launcher.main(), 0)
        env = run.call_args.kwargs['env']
        self.assertEqual(env['RAG_MODEL_URL'], launcher.ENDPOINT)
        self.assertEqual(env['RAG_MODEL_NAME'], 'openrouter/free')
        self.assertNotIn('RAG_LAUNCH_KEY', env)
        self.assertNotIn('RAG_NETWORK_MODE', env)
        self.assertNotIn('sk-or-dummy-secret', output.getvalue())
        self.assertFalse(diagnostic.call_args.args[0]['generation_verified'])

    def test_empty_input_no_auth_request(self):
        with contextlib.redirect_stdout(io.StringIO()), patch.dict(os.environ, {'RAG_LAUNCH_KEY':''}), \
             patch.object(launcher, 'diagnostic'), patch.object(launcher, 'check_key') as check:
            self.assertEqual(launcher.main(), 1)
        check.assert_not_called()

    def test_auth_request_and_private_account_fields_not_returned(self):
        requests = []
        class Opener:
            def open(self, request, timeout):
                requests.append(request)
                return Response({'data': {'label': 'private-account', 'usage': 123, 'limit_remaining': 8,
                    'free_model_daily_requests': {'used': 2, 'limit': 50, 'remaining': 48}}})
        with patch.object(launcher.urllib.request, 'build_opener', return_value=Opener()):
            value = launcher.check_key('sk-or-test')
        self.assertEqual(value, {'used': 2, 'limit': 50, 'remaining': 48})
        self.assertEqual(requests[0].full_url, launcher.KEY_URL)
        self.assertIsNone(requests[0].data)
        self.assertNotIn('private-account', json.dumps(value))

    def test_free_request_has_zero_price_and_no_paid_fallback(self):
        settings, requests = self.settings(), []
        sources = [{'ref':'R1','excerpt':'模拟规则原文：需要人工复核原图与实物。'}]
        class Opener:
            def open(inner, request, timeout):
                requests.append(request)
                return Response({'model':'example/actual-model:free','choices':[{'finish_reason':'stop',
                    'message':{'content':json.dumps(fixture_answer(sources))}}]})
        with patch.object(rag_service.urllib.request, 'build_opener', return_value=Opener()):
            answer = rag_service.call_model({}, sources, [], settings)
        body = json.loads(requests[0].data)
        self.assertEqual(body['model'], 'openrouter/free')
        self.assertEqual(body['provider']['max_price'], {'prompt':0,'completion':0,'request':0})
        self.assertTrue(body['provider']['require_parameters'])
        self.assertNotIn('models', body)
        self.assertNotIn('thinking', body)
        self.assertNotIn('plugins', body)
        self.assertEqual(settings['resolved_model'], 'example/actual-model:free')
        rag_service.validate_answer(answer, sources, [])

    def test_paid_model_blocked_before_http(self):
        with patch.object(rag_service.urllib.request, 'build_opener') as opener, self.assertRaises(ValueError):
            rag_service.call_model({}, [], [], self.settings('some/paid-model'))
        opener.assert_not_called()

    def test_config_rejects_paid_model(self):
        with patch.dict(os.environ, {'RAG_MODEL_URL':launcher.ENDPOINT,'RAG_MODEL_NAME':'some/paid-model',
                                     'RAG_API_KEY':'sk-or-test'}):
            self.assertFalse(rag_service.config()['configured'])

    def test_fixed_free_model_supported(self):
        with patch.dict(os.environ, {'RAG_MODEL_URL':launcher.ENDPOINT,'RAG_MODEL_NAME':'example/model:free',
                                     'RAG_API_KEY':'sk-or-test'}):
            self.assertTrue(rag_service.config()['configured'])
            self.assertTrue(rag_service.public_config()['free_only'])

    def test_no_key_or_credential_in_public_settings(self):
        with patch.dict(os.environ, {'RAG_MODEL_URL':launcher.ENDPOINT,'RAG_MODEL_NAME':'openrouter/free',
                                     'RAG_API_KEY':'sk-or-test-secret'}):
            public = rag_service.public_config()
        self.assertNotIn('sk-or-test-secret', json.dumps(public))


if __name__ == '__main__': unittest.main(verbosity=2)
