"""BigModel adapter: fake credentials and simulated HTTP, no real inference."""
import contextlib
import io
import json
import os
import sys
import unittest
import urllib.error
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import connect_bigmodel as launcher
import rag_service
from test_rag import fixture_answer


class Response:
    def __init__(self, value): self.value = value
    def __enter__(self): return self
    def __exit__(self, *args): pass
    def read(self, n): return json.dumps(self.value).encode()


class BigModelTests(unittest.TestCase):
    def settings(self, endpoint=None, model=None):
        return {'endpoint':endpoint or launcher.ENDPOINT, 'model':model or launcher.MODEL,
                'key':'dummy-id.dummy-secret', 'local':False, 'json_mode':True, 'timeout':10}

    def test_launcher_fixed_free_model_secret_only_in_child_environment(self):
        secret='dummy-id.dummy-secret'
        output=io.StringIO()
        with contextlib.redirect_stdout(output), patch.dict(os.environ, {'RAG_LAUNCH_KEY':secret}), \
             patch.object(launcher, 'diagnostic') as diagnostic, \
             patch.object(launcher, 'free_port', return_value=8838), \
             patch.object(launcher.subprocess, 'run', return_value=SimpleNamespace(returncode=0)) as run:
            self.assertEqual(launcher.main(), 0)
            self.assertNotIn('RAG_LAUNCH_KEY', os.environ)
        args, kwargs=run.call_args
        self.assertEqual(kwargs['env']['RAG_MODEL_URL'], launcher.ENDPOINT)
        self.assertEqual(kwargs['env']['RAG_MODEL_NAME'], 'glm-4.7-flash')
        self.assertEqual(kwargs['env']['RAG_API_KEY'], secret)
        self.assertNotIn('RAG_LAUNCH_KEY', kwargs['env'])
        self.assertNotIn(secret, output.getvalue()+' '.join(args[0])+str(diagnostic.call_args))
        record=diagnostic.call_args.args[0]
        self.assertFalse(record['network_request_sent'])
        self.assertFalse(record['authentication_verified'])
        self.assertFalse(record['generation_verified'])

    def test_startup_does_not_preflight_network_or_generate(self):
        with contextlib.redirect_stdout(io.StringIO()), patch.dict(os.environ, {'RAG_LAUNCH_KEY':'dummy-id.dummy-secret'}), \
             patch.object(launcher, 'diagnostic'), patch.object(launcher, 'free_port', return_value=8838), \
             patch.object(launcher.subprocess, 'run', return_value=SimpleNamespace(returncode=0)), \
             patch.object(rag_service.urllib.request, 'build_opener') as network:
            self.assertEqual(launcher.main(), 0)
        network.assert_not_called()

    def test_empty_key_does_not_start(self):
        with contextlib.redirect_stdout(io.StringIO()), patch.dict(os.environ, {'RAG_LAUNCH_KEY':''}), \
             patch.object(launcher, 'diagnostic'), patch.object(launcher.subprocess, 'run') as run:
            self.assertEqual(launcher.main(), 1)
        run.assert_not_called()

    def test_masked_key_does_not_start(self):
        with contextlib.redirect_stdout(io.StringIO()), patch.dict(os.environ, {'RAG_LAUNCH_KEY':'dummy.******'}), \
             patch.object(launcher, 'diagnostic'), patch.object(launcher.subprocess, 'run') as run:
            self.assertEqual(launcher.main(), 1)
        run.assert_not_called()

    def test_request_parameters_and_validated_citations(self):
        settings=self.settings()
        sources=[{'ref':'R1','excerpt':'模拟规则原文：必须人工核查原始图像。'}]
        requests=[]
        class Opener:
            def open(self, request, timeout):
                requests.append(request)
                return Response({'model':launcher.MODEL,'choices':[{'finish_reason':'stop',
                    'message':{'content':json.dumps(fixture_answer(sources))}}]})
        with patch.object(rag_service.urllib.request, 'build_opener', return_value=Opener()):
            answer=rag_service.call_model({'sample_id':'SIM-025'},sources,[],settings)
        body=json.loads(requests[0].data)
        self.assertEqual(requests[0].full_url, launcher.ENDPOINT)
        self.assertEqual(requests[0].get_header('Authorization'),'Bearer dummy-id.dummy-secret')
        self.assertEqual(body['model'],'glm-4.7-flash')
        self.assertEqual(body['thinking'],{'type':'disabled'})
        self.assertEqual(body['response_format'],{'type':'json_object'})
        self.assertEqual(body['max_tokens'],4096)
        self.assertFalse(body['stream'])
        for field in ('chat_template_kwargs','max_completion_tokens','reasoning_effort','provider','models','tools'):
            self.assertNotIn(field,body)
        rag_service.validate_answer(answer,sources,[])
        self.assertEqual(settings['resolved_model'],launcher.MODEL)

    def test_other_models_rejected_before_network(self):
        for model in ('glm-5.3','glm-4.7-flashx','GLM-4.7-Flash'):
            with self.subTest(model=model), patch.object(rag_service.urllib.request,'build_opener') as network:
                with self.assertRaises(ValueError):
                    rag_service.call_model({},[],[],self.settings(model=model))
                network.assert_not_called()

    def test_config_rejects_other_models_and_hides_key(self):
        with patch.dict(os.environ,{'RAG_MODEL_URL':launcher.ENDPOINT,'RAG_MODEL_NAME':'glm-5.3',
                                    'RAG_API_KEY':'dummy-id.dummy-secret'}):
            public=rag_service.public_config()
        self.assertFalse(public['configured'])
        self.assertIn('仅允许',public['problems'][0])
        self.assertNotIn('dummy-secret',json.dumps(public))

    def test_provider_thinking_not_sent_to_other_host(self):
        settings=self.settings(endpoint='https://other-provider.example/v1/chat/completions')
        sources=[{'ref':'R1','excerpt':'模拟规则原文：必须人工核查原始图像。'}]
        class Opener:
            def open(inner, request, timeout):
                self.assertNotIn('thinking',json.loads(request.data))
                return Response({'choices':[{'message':{'content':json.dumps(fixture_answer(sources))}}]})
        with patch.object(rag_service.urllib.request,'build_opener',return_value=Opener()):
            rag_service.call_model({},sources,[],settings)

    def test_auth_failure_no_retry_or_template_answer(self):
        settings=self.settings()
        class Opener:
            def open(self,request,timeout):
                raise urllib.error.HTTPError(launcher.ENDPOINT,401,'Unauthorized',{},
                    io.BytesIO(b'{"error":{"code":"1000","message":"invalid credentials"}}'))
        with patch.object(rag_service.urllib.request,'build_opener',return_value=Opener()):
            with self.assertRaises(rag_service.ModelHTTPError) as caught:
                rag_service.call_model({},[],[],settings)
        self.assertEqual(caught.exception.status,401)
        self.assertEqual(settings['request_options']['attempts'],1)

    def test_auth_codes_are_distinct_and_never_echo_raw_error(self):
        categories={'401':'bigmodel_token_invalid_or_expired',
                    '1000':'bigmodel_auth_failed','1001':'bigmodel_auth_missing',
                    '1003':'bigmodel_auth_expired','1005':'bigmodel_auth_second_factor'}
        for code,category in categories.items():
            with self.subTest(code=code):
                private='dummy-id.private-secret-must-not-be-echoed'
                error=urllib.error.HTTPError(launcher.ENDPOINT,401,'Unauthorized',{},
                    io.BytesIO(json.dumps({'error':{'code':code,'message':private}}).encode()))
                actual=rag_service.classify_provider_error(error,'bigmodel')
                self.assertEqual(actual,category)
                message=rag_service.provider_error_message(401,actual)
                self.assertIn(code,message)
                self.assertNotIn(private,message)

    def test_numeric_401_response_from_live_probe_is_supported(self):
        error=urllib.error.HTTPError(launcher.ENDPOINT,401,'Unauthorized',{},
            io.BytesIO(json.dumps({'error':{'code':401,'message':'令牌已过期或验证不正确'}}).encode()))
        safe={}
        category=rag_service.classify_provider_error(error,'bigmodel',safe)
        self.assertEqual(category,'bigmodel_token_invalid_or_expired')
        self.assertEqual(safe,{'http_status':401,'body_format':'json_error_object','provider_code':'401'})

    def test_diagnostic_never_contains_body_or_credentials(self):
        private='sensitive-key-and-server-original-message'
        error=urllib.error.HTTPError(launcher.ENDPOINT,401,'Unauthorized',{},
            io.BytesIO(json.dumps({'error':{'code':private,'message':private}}).encode()))
        safe={}
        rag_service.classify_provider_error(error,'bigmodel',safe)
        self.assertNotIn(private,json.dumps(safe))
        self.assertEqual(safe['provider_code'],'unrecognized')

    def test_non_json_401_is_reported_as_unknown_source(self):
        error=urllib.error.HTTPError(launcher.ENDPOINT,401,'Unauthorized',{},
            io.BytesIO(b'<html>private proxy response</html>'))
        safe={}
        category=rag_service.classify_provider_error(error,'bigmodel',safe)
        self.assertEqual(category,'request_rejected')
        self.assertEqual(safe['body_format'],'non_json')
        self.assertNotIn('private',json.dumps(safe))

    def test_auth_code_not_applied_to_other_provider(self):
        error=urllib.error.HTTPError('https://another.example',401,'Unauthorized',{},
            io.BytesIO(b'{"error":{"code":"1005","message":"secret"}}'))
        self.assertEqual(rag_service.classify_provider_error(error),'request_rejected')

    def test_unrecognized_code_not_reflected_to_browser(self):
        error=urllib.error.HTTPError(launcher.ENDPOINT,401,'Unauthorized',{},
            io.BytesIO(b'{"error":{"code":"private-unknown-code","message":"private raw body"}}'))
        category=rag_service.classify_provider_error(error,'bigmodel')
        self.assertEqual(category,'request_rejected')
        message=rag_service.provider_error_message(401,category)
        self.assertNotIn('private',message)
        self.assertIn('账号认证状态',message)

    def test_documented_429_codes_distinguish_limits_and_accounts(self):
        for code,(expected,hint) in rag_service.BIGMODEL_LIMITS.items():
            with self.subTest(code=code):
                error=urllib.error.HTTPError(launcher.ENDPOINT,429,'Too Many Requests',{},
                    io.BytesIO(json.dumps({'error':{'code':code,'message':'private provider body dummy-secret'}}).encode()))
                safe={}
                category=rag_service.classify_provider_error(error,'bigmodel',safe)
                self.assertEqual(category,expected)
                self.assertEqual(safe['provider_code'],code)
                message=rag_service.provider_error_message(429,category,code)
                self.assertIn(code,message)
                self.assertIn(hint,message)
                self.assertNotIn('dummy-secret',message+json.dumps(safe))

    def test_generic_429_not_asserted_to_be_frequency_limit(self):
        error=urllib.error.HTTPError(launcher.ENDPOINT,429,'Too Many Requests',{},
            io.BytesIO(b'{"error":{"code":"429","message":"private body"}}'))
        safe={}
        category=rag_service.classify_provider_error(error,'bigmodel',safe)
        self.assertEqual(category,'bigmodel_limit_unspecified')
        message=rag_service.provider_error_message(429,category,safe['provider_code'])
        self.assertIn('具体原因尚未识别',message)
        self.assertIn('429',message)

    def test_429_unknown_numeric_code_retained_without_raw_body(self):
        error=urllib.error.HTTPError(launcher.ENDPOINT,429,'Too Many Requests',{},
            io.BytesIO(b'{"error":{"code":"1999","message":"dummy secret body"}}'))
        safe={}
        rag_service.classify_provider_error(error,'bigmodel',safe)
        self.assertEqual(safe['provider_code'],'1999')
        self.assertNotIn('secret',json.dumps(safe))

    def test_429_not_retried_and_never_changes_free_model(self):
        settings=self.settings()
        class Opener:
            def open(self,request,timeout):
                self_body=json.loads(request.data)
                if self_body['model']!='glm-4.7-flash':raise AssertionError('Model changed')
                raise urllib.error.HTTPError(launcher.ENDPOINT,429,'Too Many Requests',{},
                    io.BytesIO(b'{"error":{"code":"1302","message":"private body"}}'))
        with patch.object(rag_service.urllib.request,'build_opener',return_value=Opener()):
            with self.assertRaises(rag_service.ModelHTTPError) as caught:
                rag_service.call_model({},[],[],settings)
        self.assertEqual(caught.exception.category,'bigmodel_rate_limit')
        self.assertEqual(settings['request_options']['attempts'],1)


if __name__=='__main__': unittest.main(verbosity=2)
