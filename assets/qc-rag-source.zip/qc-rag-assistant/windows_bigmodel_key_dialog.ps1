$ErrorActionPreference = 'Stop'
$ragRoot = [IO.Path]::GetDirectoryName($env:RAG_LAUNCH_SCRIPT)
$ragMode = $env:RAG_KEY_MODE
$ragSelfTest = $env:RAG_DIALOG_SELF_TEST -eq '1'

function Start-RagBackend([string]$PlainKey, [string]$Source) {
    $ragExit = 1
    try {
        $env:RAG_LAUNCH_KEY = $PlainKey
        $env:RAG_KEY_SOURCE = $Source
        & $env:RAG_PY $env:RAG_LAUNCH_SCRIPT --native-input | Out-Host
        $ragExit = $LASTEXITCODE
    }
    finally {
        Remove-Item Env:RAG_LAUNCH_KEY -ErrorAction SilentlyContinue
        Remove-Item Env:RAG_KEY_SOURCE -ErrorAction SilentlyContinue
    }
    return $ragExit
}

# Self-test never reads, writes or deletes the user's saved credential.
if (-not $ragSelfTest) {
    if ($ragMode -eq 'clear') {
        try {
            Clear-RagCredential $ragRoot
            Write-Host '已清除本机保存的智谱密钥。下次启动会重新要求输入。'
            Write-Host '请关闭已运行的助手以释放运行中凭证；此操作不会撤销平台 API Key。'
            exit 0
        }
        catch { Write-Host '清除失败，请检查目录权限。'; exit 1 }
    }
    if ($ragMode -ne 'change') {
        $ragSaved = $null
        try {
            $ragSaved = Read-RagCredential $ragRoot
            if ($null -ne $ragSaved) {
                $ragPlain = Normalize-RagInput (Get-RagPlainKey $ragSaved)
                if (-not (Test-RagInput $ragPlain)) { throw 'Invalid saved key' }
                $ragSaved.Dispose()
                $ragSaved = $null
                Write-Host '已自动读取 Windows 当前用户加密保存的智谱密钥。'
                Write-Host '需要更换或清除时，请使用同目录的对应入口。'
                $ragExit = Start-RagBackend $ragPlain 'saved'
                $ragPlain = $null
                exit $ragExit
            }
        }
        catch { Write-Host '已保存密钥无法读取，将重新要求输入；取消不会覆盖原保存内容。' }
        finally { if ($null -ne $ragSaved) { $ragSaved.Dispose() } }
    }
}

Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.Application]::EnableVisualStyles()
$ragForm = New-Object System.Windows.Forms.Form
$ragForm.Text = 'BigModel API Key - 2026.11.01.bigmodel.5'
$ragForm.ClientSize = [System.Drawing.Size]::new(560, 225)
$ragForm.StartPosition = 'CenterScreen'
$ragForm.FormBorderStyle = 'FixedDialog'
$ragForm.MaximizeBox = $false
$ragForm.MinimizeBox = $false
$ragForm.TopMost = $true
$ragLabel = New-Object System.Windows.Forms.Label
$ragLabel.Text = '请粘贴智谱的完整 API Key，密钥不会显示或发送到网页。'
$ragLabel.Location = [System.Drawing.Point]::new(20, 16)
$ragLabel.Size = [System.Drawing.Size]::new(520, 36)
$ragBox = New-Object System.Windows.Forms.TextBox
$ragBox.Location = [System.Drawing.Point]::new(20, 58)
$ragBox.Size = [System.Drawing.Size]::new(520, 28)
$ragBox.UseSystemPasswordChar = $true
$ragRemember = New-Object System.Windows.Forms.CheckBox
$ragRemember.Text = '记住密钥（Windows 当前用户加密，下次自动读取）'
$ragRemember.Location = [System.Drawing.Point]::new(20, 100)
$ragRemember.Size = [System.Drawing.Size]::new(520, 26)
$ragRemember.Checked = $true
$ragHint = New-Object System.Windows.Forms.Label
$ragHint.Text = '不勾选则仅本次使用；更换时取消，不会修改原保存密钥。'
$ragHint.Location = [System.Drawing.Point]::new(20, 132)
$ragHint.Size = [System.Drawing.Size]::new(520, 26)
$ragOk = New-Object System.Windows.Forms.Button
$ragOk.Text = '连接'
$ragOk.Location = [System.Drawing.Point]::new(350, 175)
$ragOk.DialogResult = 'OK'
$ragCancel = New-Object System.Windows.Forms.Button
$ragCancel.Text = '取消'
$ragCancel.Location = [System.Drawing.Point]::new(450, 175)
$ragCancel.DialogResult = 'Cancel'
$ragForm.Controls.AddRange(@($ragLabel, $ragBox, $ragRemember, $ragHint, $ragOk, $ragCancel))
$ragForm.AcceptButton = $ragOk
$ragForm.CancelButton = $ragCancel
$ragForm.Add_Shown({ [void]$ragBox.Focus(); $ragForm.Activate() })

if ($ragSelfTest) {
    if (-not $ragBox.UseSystemPasswordChar -or -not $ragRemember.Checked -or $ragForm.Controls.Count -ne 6) { throw 'Password dialog check failed' }
    Write-Output 'WINDOWS_DIALOG_SELF_TEST_OK: controls=6; masked=True; remember=True; no_key; no_network; no_credential_read'
    $ragForm.Dispose()
    exit 0
}

while ($true) {
    if ($ragForm.ShowDialog() -ne 'OK') { $ragForm.Dispose(); exit 0 }
    $ragPlain = Normalize-RagInput $ragBox.Text
    if (-not (Test-RagInput $ragPlain)) {
        [void][System.Windows.Forms.MessageBox]::Show('请输入完整密钥，不能包含星号、省略号或内部空白。', '输入检查')
        continue
    }
    $ragSecure = $null
    try {
        if ($ragRemember.Checked) {
            $ragSecure = New-RagSecureString $ragPlain
            Save-RagCredential $ragRoot $ragSecure
            Write-Host '密钥已由 Windows 当前用户加密保存在本机。'
        } else {
            Clear-RagCredential $ragRoot
            Write-Host '本次不记住密钥；已有本机保存内容已清除。'
        }
    }
    catch {
        [void][System.Windows.Forms.MessageBox]::Show('保存或清除失败，尚未启动。请检查目录权限，或取消退出。', '密钥存储')
        continue
    }
    finally { if ($null -ne $ragSecure) { $ragSecure.Dispose() } }
    break
}
$ragBox.Clear()
$ragForm.Dispose()
$ragExit = Start-RagBackend $ragPlain 'input'
$ragPlain = $null
exit $ragExit
