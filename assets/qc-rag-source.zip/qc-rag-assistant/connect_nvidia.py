"""NVIDIA launcher: native secret input, PUBLIC catalog lookup, no inference preflight."""
import getpass
import json
import os
import re
import subprocess
import sys
import urllib.error
import urllib.request
from pathlib import Path

from connect_deepseek import windows_dialog, normalize_key, key_input_error, free_port
from provider_connection import USER_AGENT, http_summary
from rag_service import NoRedirect

ROOT = Path(__file__).resolve().parent
ENDPOINT = "https://integrate.api.nvidia.com/v1/chat/completions"
MODELS_URL = "https://integrate.api.nvidia.com/v1/models"
PREFERRED_MODELS = ("nvidia/nemotron-3.5-lightning-30b-a3b",)


def available_models():
    request = urllib.request.Request(MODELS_URL, headers={"Accept": "application/json", "Content-Type": "application/json", "User-Agent": USER_AGENT})
    with urllib.request.build_opener(NoRedirect()).open(request, timeout=15) as response:
        raw = response.read(512 * 1024 + 1)
    if len(raw) > 512 * 1024:
        raise ValueError("模型列表响应过大")
    value = json.loads(raw)
    rows = value.get("data", []) if isinstance(value, dict) else []
    if not isinstance(rows, list):
        raise ValueError("模型列表格式无效")
    return list(dict.fromkeys(r["id"] for r in rows if isinstance(r, dict) and r.get("active") is not False
        and isinstance(r.get("id"), str) and re.fullmatch(r"[A-Za-z0-9_./-]{1,150}", r["id"])))


def select_model(models):
    return next((name for name in PREFERRED_MODELS if name in models), None)


def diagnostic(value):
    try:
        target = ROOT / "data" / "nvidia_connection_diagnostic.json"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    except OSError:
        pass


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    print("NVIDIA 模型启动向导 — 2026.11.01.nvidia.1\n")
    print("接口：" + ENDPOINT)
    print("优先使用 " + PREFERRED_MODELS[0] + "，以官方接口返回的可用列表为准。")
    print("请使用 NVIDIA API Key：https://build.nvidia.com/nvidia/nemotron-3.5-lightning-30b-a3b")
    print("官方模型页当前提供免费试用端点；权限、额度和限速以账号及平台为准，非无限免费。")
    print("查询公开模型目录不发送密钥、样本或标准，不自动生成文本。密钥不写入文件或网页。\n")
    value = os.environ.pop("RAG_LAUNCH_KEY", None)
    key = normalize_key(value if value is not None else getpass.getpass("NVIDIA API Key（隐藏输入）："))
    issue = key_input_error(key)
    if issue:
        diagnostic({"status": "input_rejected", "reason_kind": issue, "network_request_sent": False})
        print("未收到完整密钥，请粘贴 NVIDIA 创建时复制的完整值；此时尚未请求 NVIDIA。")
        return 1
    print("正在查询 NVIDIA 公开模型目录（此步骤不验证密钥）…", flush=True)
    try:
        models = available_models()
    except urllib.error.HTTPError as exc:
        summary = http_summary(exc, key)
        diagnostic({"status": "model_list_failed", **summary})
        print("检查失败：HTTP " + str(exc.code) + "；" + summary["reason"])
        if exc.code == 403:
            print("NVIDIA 或其接入节点拒绝访问，可能涉及访问限制/组织权限，不能仅据此认定密钥有误。")
        else:
            print("请检查 NVIDIA 平台访问情况；此步骤未发送密钥。")
        print("脱敏记录：data/nvidia_connection_diagnostic.json。")
        return 1
    except Exception:
        diagnostic({"status": "connection_failed", "reason": "网络、超时或响应格式异常"})
        print("未能读取 NVIDIA 模型列表，请检查网络与服务状态；密钥未保存。")
        return 1
    model = select_model(models)
    if not model:
        diagnostic({"status": "no_compatible_model", "models": models, "generation_verified": False})
        print("公开目录中未找到指定的 NVIDIA 文本模型，未自动改用其他模型；请更新模型配置。")
        return 1
    diagnostic({"status": "catalog_accessible", "selected_model": model,
                "authentication_verified": False, "generation_verified": False})
    print("公开目录可访问。本次模型：" + model)
    print("目录无需密钥即可读取，因此尚未验证密钥、试用权限或生成能力；以页面真实请求为准。")
    port = free_port()
    environment = os.environ.copy()
    environment.update({"RAG_MODEL_URL": ENDPOINT, "RAG_MODEL_NAME": model,
                        "RAG_API_KEY": key, "RAG_JSON_MODE": "1", "RAG_TIMEOUT_SECONDS": "60"})
    environment.pop("RAG_NETWORK_MODE", None)
    print("\n请使用新页面：http://127.0.0.1:" + str(port) + "/")
    print("生成时将当前样本上下文与检索片段发给 NVIDIA，请先使用模拟资料。")
    print("保持启动窗口打开。\n", flush=True)
    return subprocess.run([sys.executable, str(ROOT / "app.py"), "--open", "--port", str(port)],
                          cwd=ROOT, env=environment).returncode


if __name__ == "__main__":
    try:
        if os.name == "nt" and "--native-input" not in sys.argv:
            raise SystemExit(windows_dialog("--self-test" in sys.argv,
                launcher_file=ROOT / "connect_nvidia.py", provider="NVIDIA"))
        raise SystemExit(main())
    except (KeyboardInterrupt, EOFError):
        print("\n启动已取消。")
    except OSError:
        print("无法启动，请检查文件完整性和可用端口。")
        raise SystemExit(1)
