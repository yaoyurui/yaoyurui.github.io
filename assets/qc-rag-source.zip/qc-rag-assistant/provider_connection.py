"""DeepSeek connection diagnostics. Model-list requests only; never persist keys."""
import json
import re
import urllib.error
import urllib.parse
import urllib.request

USER_AGENT = "QC-RAG-Assistant/2026.11.01"


def redact_reason(value, key):
    value = str(value)
    for secret in (key, urllib.parse.quote(key, safe="")):
        if secret:
            value = value.replace(secret, "[密钥已隐藏]")
    value = re.sub(r"(?i)Bearer\s+\S+", "Bearer [已隐藏]", value)
    value = re.sub(r"(?i)sk-[a-z0-9_.-]+", "[密钥已隐藏]", value)
    value = re.sub(r"[a-zA-Z0-9_+/=-]{24,}", "[长标识已隐藏]", value)
    value = re.sub(r"<[^>]*>", " ", value)
    return " ".join(value.split())[:240]


def http_summary(error, key):
    raw = error.read(16384).decode("utf-8", "replace")
    try:
        obj = json.loads(raw)
        entry = obj.get("error", obj) if isinstance(obj, dict) else {}
        reason = entry.get("message", "接口未提供错误摘要") if isinstance(entry, dict) else "接口未提供错误摘要"
        kind = "json"
    except ValueError:
        reason, kind = raw, "html" if "<html" in raw.casefold() else "text"
    return {"status": error.code, "body_kind": kind, "reason": redact_reason(reason, key)}


class DiscoveryError(Exception):
    def __init__(self, attempts):
        self.attempts = attempts
        last = attempts[-1] if attempts else {}
        self.status = last.get("status")
        self.reason = last.get("reason", "无法连接模型列表接口")
        super().__init__("模型列表检查未通过")


def discover(key, no_redirect):
    attempts = []
    has_proxy = any(k in urllib.request.getproxies() for k in ("http", "https", "all"))
    routes = ("https://api.deepseek.com/models", "https://api.deepseek.com/v1/models")
    for endpoint in routes:
        modes = ("system", "direct") if has_proxy else ("direct",)
        for mode in modes:
            handlers = [no_redirect()]
            if mode == "direct":
                handlers.append(urllib.request.ProxyHandler({}))
            request = urllib.request.Request(endpoint, method="GET", headers={
                "Authorization": "Bearer " + key, "Accept": "application/json",
                "Content-Type": "application/json", "User-Agent": USER_AGENT})
            try:
                with urllib.request.build_opener(*handlers).open(request, timeout=15) as response:
                    data = response.read(512 * 1024 + 1)
                if len(data) > 512 * 1024:
                    raise ValueError("模型列表响应过大")
                payload = json.loads(data)
                records = payload.get("data", []) if isinstance(payload, dict) else []
                if not isinstance(records, list):
                    raise ValueError("模型列表格式无效")
                models = list(dict.fromkeys(r["id"] for r in records if isinstance(r, dict)
                    and isinstance(r.get("id"), str) and re.fullmatch(r"deepseek[-a-zA-Z0-9_.]{1,100}", r["id"])))
                if not models:
                    raise ValueError("未返回可用的 DeepSeek 模型")
                attempts.append({"endpoint": endpoint, "network": mode, "status": 200})
                return models, {"attempts": attempts, "models": models, "status": "models_available",
                                "endpoint": endpoint, "network": mode}
            except urllib.error.HTTPError as exc:
                attempts.append({"endpoint": endpoint, "network": mode, **http_summary(exc, key)})
                if exc.code in (400, 404, 407):
                    continue
                # Never hide authentication, billing, permission or rate-limit errors via retries.
                raise DiscoveryError(attempts) from None
            except (urllib.error.URLError, OSError):
                attempts.append({"endpoint": endpoint, "network": mode, "status": None,
                                 "reason": "网络连接失败或超时"})
            except (ValueError, TypeError):
                attempts.append({"endpoint": endpoint, "network": mode, "status": None,
                                 "reason": "未收到有效的模型列表 JSON"})
    raise DiscoveryError(attempts)
