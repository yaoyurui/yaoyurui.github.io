﻿$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.Application]::EnableVisualStyles()

$ragForm = New-Object System.Windows.Forms.Form
$ragProvider = $env:RAG_KEY_PROVIDER
if ([string]::IsNullOrWhiteSpace($ragProvider)) { $ragProvider = 'DeepSeek' }
$ragForm.Text = $ragProvider + ' API Key - 2026.11.01.bigmodel.3'
$ragForm.ClientSize = [System.Drawing.Size]::new(540, 180)
$ragForm.StartPosition = 'CenterScreen'
$ragForm.FormBorderStyle = 'FixedDialog'
$ragForm.MaximizeBox = $false
$ragForm.MinimizeBox = $false
$ragForm.TopMost = $true

$ragLabel = New-Object System.Windows.Forms.Label
$ragLabel.Text = '请粘贴 ' + $ragProvider + ' 的完整 API Key，内容以圆点隐藏，密钥不会写入文件。'
$ragLabel.Location = [System.Drawing.Point]::new(20, 20)
$ragLabel.Size = [System.Drawing.Size]::new(500, 32)

$ragBox = New-Object System.Windows.Forms.TextBox
$ragBox.Location = [System.Drawing.Point]::new(20, 60)
$ragBox.Size = [System.Drawing.Size]::new(500, 28)
$ragBox.UseSystemPasswordChar = $true

$ragOk = New-Object System.Windows.Forms.Button
$ragOk.Text = '连接'
$ragOk.Location = [System.Drawing.Point]::new(330, 115)
$ragOk.DialogResult = 'OK'
$ragCancel = New-Object System.Windows.Forms.Button
$ragCancel.Text = '取消'
$ragCancel.Location = [System.Drawing.Point]::new(430, 115)
$ragCancel.DialogResult = 'Cancel'

$ragForm.Controls.AddRange(@($ragLabel, $ragBox, $ragOk, $ragCancel))
$ragForm.AcceptButton = $ragOk
$ragForm.CancelButton = $ragCancel
$ragForm.Add_Shown({ [void]$ragBox.Focus(); $ragForm.Activate() })

# Headless construction test: no secret requested, no window shown, no network call.
if ($env:RAG_DIALOG_SELF_TEST -eq '1') {
    if (-not $ragBox.UseSystemPasswordChar -or $ragForm.Controls.Count -ne 4) {
        throw 'Password dialog construction check failed'
    }
    Write-Output 'WINDOWS_DIALOG_SELF_TEST_OK: controls=4; masked=True; no_key; no_network'
    $ragForm.Dispose()
    exit 0
}

if ($ragForm.ShowDialog() -ne 'OK') {
    $ragForm.Dispose()
    exit 0
}
$ragExit = 1
try {
    $env:RAG_LAUNCH_KEY = $ragBox.Text
    $ragBox.Clear()
    $ragForm.Dispose()
    & $env:RAG_PY $env:RAG_LAUNCH_SCRIPT --native-input
    $ragExit = $LASTEXITCODE
}
finally {
    Remove-Item Env:RAG_LAUNCH_KEY -ErrorAction SilentlyContinue
}
exit $ragExit
