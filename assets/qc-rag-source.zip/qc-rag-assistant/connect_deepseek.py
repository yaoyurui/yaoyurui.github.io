"""Interactive launcher: discovers available models, never persists keys or generates text."""
import getpass
import json
import os
import re
import socket
import subprocess
import sys
import urllib.error
import urllib.request
from pathlib import Path
from rag_service import NoRedirect
from provider_connection import DiscoveryError, discover

ROOT = Path(__file__).resolve().parent
ENDPOINT = "https://api.deepseek.com/chat/completions"
MODEL = "deepseek-flash"
MODELS_URL = "https://api.deepseek.com/models"


def windows_dialog(self_test=False, launcher_file=None, provider="DeepSeek", mode="normal"):
    """Pass Unicode script as one process argument, avoiding CMD's script parsing."""
    script = (ROOT / "windows_key_dialog.ps1").read_text(encoding="utf-8-sig")
    if provider == "BigModel":
        script = ((ROOT / "windows_credential_store.ps1").read_text(encoding="utf-8-sig") + "\n" +
                  (ROOT / "windows_bigmodel_key_dialog.ps1").read_text(encoding="utf-8-sig"))
    powershell = Path(os.environ.get("SystemRoot", r"C:\Windows")) / "System32/WindowsPowerShell/v1.0/powershell.exe"
    environment = os.environ.copy()
    environment.update({"RAG_PY": sys.executable,
                        "RAG_LAUNCH_SCRIPT": str(launcher_file or ROOT / "connect_deepseek.py"),
                        "RAG_KEY_PROVIDER": provider})
    environment["RAG_KEY_MODE"] = mode if mode in ("normal", "change", "clear") else "normal"
    environment.pop("RAG_LAUNCH_KEY", None)
    if self_test:
        environment["RAG_DIALOG_SELF_TEST"] = "1"
    else:
        environment.pop("RAG_DIALOG_SELF_TEST", None)
    # No -File execution-policy changes, no shell=True, and no key in arguments.
    return subprocess.run([str(powershell), "-NoProfile", "-STA", "-Command", script],
                          cwd=ROOT, env=environment).returncode


def available_models(key):
    try:
        models, diagnostic = discover(key, NoRedirect)
    except DiscoveryError as exc:
        save_diagnostic({"status": "failed", "attempts": exc.attempts})
        raise
    save_diagnostic(diagnostic)
    if diagnostic["network"] == "direct":
        os.environ["RAG_NETWORK_MODE"] = "direct"
    return models


def save_diagnostic(payload):
    try:
        target = ROOT / "data" / "deepseek_connection_diagnostic.json"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    except OSError:
        pass


def select_model(models):
    for name in (MODEL, "deepseek-chat", "deepseek-v4-flash", "deepseek-v4-pro", "deepseek-reasoner"):
        if name in models:
            return name
    return models[0]


def free_port():
    for port in range(8790, 8840):
        with socket.socket() as probe:
            if os.name == "nt" and hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
                probe.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
            try:
                probe.bind(("127.0.0.1", port))
            except OSError:
                continue
            return port
    raise OSError("8790–8839 没有可用端口，请关闭本工具的旧启动窗口后重试。")


def normalize_key(value):
    # Windows getwch() can include the Ctrl+V key code itself during paste.
    # Remove that input artifact, plus surrounding clipboard formatting only.
    value = str(value or "").replace("\x16", "").strip(" \t\r\n\ufeff\u200b\u2060")
    pairs = {'"': '"', "'": "'", '“': '”', '‘': '’', '`': '`'}
    if len(value) > 1 and value[0] in pairs and value[-1] == pairs[value[0]]:
        value = value[1:-1].strip()
    if value.lower().startswith("bearer "):
        value = value[7:].strip()
    return value


def key_input_error(key):
    if not key:
        return "empty"
    if "*" in key or "…" in key or "..." in key:
        return "masked"
    if any(ord(c) > 126 for c in key):
        return "non_ascii"
    if any(c.isspace() for c in key):
        return "whitespace"
    if any(ord(c) < 33 for c in key):
        return "control_character"
    return ""


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    print("DeepSeek 模型配置与启动向导（启动修复版 2026.11.01.rag.5）\n")
    print("接口：" + ENDPOINT)
    print("优先模型：" + MODEL + "（实际以账号可用模型列表为准）")
    print("密钥仅传入本次后端进程的环境变量，不写入文件或网页。")
    print("输入后先向 DeepSeek 查询可用模型列表，不发送样本或标准，不生成文本。")
    print("只有在页面点击生成建议并确认发送时才调用文本生成接口。")
    print("请先在 https://platform.deepseek.com/ 创建 API Key。\n")
    native_key = os.environ.pop("RAG_LAUNCH_KEY", None)
    method = "windows_secure_prompt" if native_key is not None else "python_hidden_input"
    key = normalize_key(native_key if native_key is not None else
        getpass.getpass("请输入 DeepSeek API Key（输入不会显示），然后按回车："))
    error = key_input_error(key)
    if error:
        save_diagnostic({"status": "input_rejected", "reason_kind": error,
                         "input_method": method, "network_request_sent": False})
        descriptions = {"empty": "输入框没有收到字符；请在原窗口重新粘贴后按回车。",
                        "masked": "收到的是包含星号或省略号的隐藏值，需要创建时复制的完整值。",
                        "non_ascii": "输入中仍含非英文字符，请确认复制范围没有包含中文说明。",
                        "whitespace": "输入中有内部空格或换行，请仅复制一条完整密钥。",
                        "control_character": "终端收到了额外按键字符，请从新版 CMD 的 Windows 隐藏输入重新启动。"}
        print("本地输入未通过：" + descriptions[error])
        print("此时尚未请求 DeepSeek，不能据此判断密钥是否有效。")
        print("已取消启动；不会修改其他服务。")
        return 1
    print("\n正在检查账号可用模型列表…", flush=True)
    try:
        models = available_models(key)
    except DiscoveryError as exc:
        print("检查失败：" + ("HTTP " + str(exc.status) if exc.status else "网络或响应异常"))
        print("已脱敏的原因：" + (exc.reason or "服务未返回错误摘要"))
        print("诊断记录：" + str(ROOT / "data" / "deepseek_connection_diagnostic.json"))
        print("请保留窗口提示；暂时无需再次更换密钥。")
        return 1
    except urllib.error.HTTPError as exc:
        reason = {401: "API Key 验证失败", 402: "账号余额不足", 429: "接口限流"}.get(exc.code, "模型列表查询被拒绝")
        print(f"检查失败：HTTP {exc.code}，{reason}。请核对后重试；不会显示密钥或原始错误正文。")
        return 1
    except Exception:
        print("未能取得有效的模型列表，请检查网络或服务状态后重试；尚未启动新服务。")
        return 1
    model = select_model(models)
    print("账号返回的可用模型：" + "、".join(models[:20]))
    if model != MODEL:
        print("预填模型在账号列表中不可用；本次改用列表中的模型：" + model)
    else:
        print("本次使用模型：" + model)
    port = free_port()
    environment = os.environ.copy()
    environment.update({"RAG_MODEL_URL": ENDPOINT, "RAG_MODEL_NAME": model,
                        "RAG_API_KEY": key, "RAG_JSON_MODE": "1", "RAG_TIMEOUT_SECONDS": "60"})
    # Always start a fresh port: existing unconfigured services cannot be reused accidentally.
    print("\n即将启动新页面：http://127.0.0.1:" + str(port) + "/")
    print("请使用新打开的页面，并保持本窗口打开。")
    print("配置已交给后端；是否连通仍需在页面中实际生成一次建议确认。\n", flush=True)
    return subprocess.run([sys.executable, str(ROOT / "app.py"), "--open", "--port", str(port)],
                          cwd=ROOT, env=environment).returncode


if __name__ == "__main__":
    try:
        if os.name == "nt" and "--native-input" not in sys.argv:
            raise SystemExit(windows_dialog("--self-test" in sys.argv))
        raise SystemExit(main())
    except (KeyboardInterrupt, EOFError):
        print("\n启动已取消。")
    except OSError:
        print("无法启动，请检查文件完整性以及本机端口是否可用。")
        raise SystemExit(1)
