"""OpenRouter free-only launcher. Native secret input; no secret files/arguments."""
import getpass
import json
import os
import subprocess
import sys
import urllib.error
import urllib.request
from pathlib import Path

from connect_deepseek import windows_dialog, normalize_key, key_input_error, free_port
from provider_connection import USER_AGENT, http_summary
from rag_service import NoRedirect

ROOT = Path(__file__).resolve().parent
ENDPOINT = "https://openrouter.ai/api/v1/chat/completions"
KEY_URL = "https://openrouter.ai/api/v1/key"
MODEL = "openrouter/free"


def check_key(key):
    request = urllib.request.Request(KEY_URL, headers={"Authorization": "Bearer " + key,
        "Accept": "application/json", "User-Agent": USER_AGENT})
    with urllib.request.build_opener(NoRedirect()).open(request, timeout=15) as response:
        raw = response.read(128 * 1024 + 1)
    if len(raw) > 128 * 1024:
        raise ValueError("密钥检查响应过大")
    payload = json.loads(raw)
    if not isinstance(payload, dict) or not isinstance(payload.get("data"), dict):
        raise ValueError("未收到有效的鉴权结果")
    # Return only free-request counters, never account labels, balances or identifiers.
    counters = payload["data"].get("free_model_daily_requests", {})
    return {name: counters[name] for name in ("used", "limit", "remaining") if
            isinstance(counters, dict) and type(counters.get(name)) is int and counters[name] >= 0}


def diagnostic(value):
    try:
        target = ROOT / "data" / "openrouter_connection_diagnostic.json"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    except OSError:
        pass


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    print("OpenRouter 免费模型启动向导 — 2026.11.01.openrouter.1\n")
    print("接口：" + ENDPOINT + "\n模型：" + MODEL)
    print("只请求免费路由，不配置付费模型兜底；仍受平台免费额度和可用性限制。")
    print("需要 OpenRouter 自己的 API Key：https://openrouter.ai/settings/keys")
    print("密钥仅用于本次后端进程，不写入文件或网页。\n")
    value = os.environ.pop("RAG_LAUNCH_KEY", None)
    key = normalize_key(value if value is not None else getpass.getpass("OpenRouter API Key（隐藏输入）："))
    issue = key_input_error(key)
    if issue:
        diagnostic({"status": "input_rejected", "reason_kind": issue, "network_request_sent": False})
        print("本地未收到完整密钥。请在密码输入框中粘贴 OpenRouter 创建时复制的完整值；尚未发送接口请求。")
        return 1
    print("正在检查 OpenRouter 密钥（不发送样本或标准，不生成文本）…", flush=True)
    try:
        counters = check_key(key)
    except urllib.error.HTTPError as exc:
        summary = http_summary(exc, key)
        diagnostic({"status": "authentication_failed", **summary})
        print("检查失败：HTTP " + str(exc.code) + "；" + summary["reason"])
        print("请确认使用 OpenRouter 的 API Key。详细脱敏记录保存在 data/openrouter_connection_diagnostic.json。")
        return 1
    except Exception:
        diagnostic({"status": "connection_failed", "reason": "网络、超时或响应格式异常"})
        print("无法完成密钥检查，请确认本机能访问 OpenRouter；密钥未保存。")
        return 1
    diagnostic({"status": "key_verified", "requested_model": MODEL, "free_only": True, "free_daily_requests": counters,
                "generation_verified": False})
    print("密钥检查通过。")
    if "remaining" in counters:
        print("平台报告今日剩余免费请求：" + str(counters["remaining"]))
    print("鉴权通过不代表模型已生成成功；请在页面实际生成一次建议确认。")
    port = free_port()
    environment = os.environ.copy()
    environment.update({"RAG_MODEL_URL": ENDPOINT, "RAG_MODEL_NAME": MODEL,
                        "RAG_API_KEY": key, "RAG_JSON_MODE": "1", "RAG_TIMEOUT_SECONDS": "60"})
    # Do not inherit the DeepSeek provider's diagnostic networking preference.
    environment.pop("RAG_NETWORK_MODE", None)
    print("\n请使用新打开的页面：http://127.0.0.1:" + str(port) + "/")
    print("生成时会将当前样本上下文和条款发送给 OpenRouter 及其选中的模型提供方。")
    print("先用模拟资料测试，保持本窗口打开。\n", flush=True)
    return subprocess.run([sys.executable, str(ROOT / "app.py"), "--open", "--port", str(port)],
                          cwd=ROOT, env=environment).returncode


if __name__ == "__main__":
    try:
        if os.name == "nt" and "--native-input" not in sys.argv:
            raise SystemExit(windows_dialog("--self-test" in sys.argv,
                launcher_file=ROOT / "connect_openrouter.py", provider="OpenRouter"))
        raise SystemExit(main())
    except (KeyboardInterrupt, EOFError):
        print("\n启动已取消。")
    except OSError:
        print("无法启动，请检查文件完整性和本机可用端口。")
        raise SystemExit(1)
