"""Run actual DPAPI tests from Explorer under the signed-in Windows user.

Only synthetic keys and temporary directories are used; no model calls.
"""
import json
from pathlib import Path
import sys
import unittest

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tests'))
from test_credentials import CredentialTests

if __name__=='__main__':
    if hasattr(sys.stdout,'reconfigure'):sys.stdout.reconfigure(encoding='utf-8')
    print('Windows 当前用户加密自检：仅测试虚构密钥，不读取真实已保存密钥，不联网。',flush=True)
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(CredentialTests))
    status='ok' if result.wasSuccessful() and not result.skipped else 'profile_unavailable' if result.skipped else 'failed'
    record={'status':status,'tests_run':result.testsRun,'skipped':len(result.skipped),
            'real_user_key_read':False,'network_request_sent':False}
    try:
        target=ROOT/'data'/'credential_selftest.json'
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
    except OSError:pass
    print('加密自检通过。' if status=='ok' else '当前 Windows 用户加密自检未通过；请使用已登录用户从资源管理器双击本入口，勿从受限服务进程运行。')
    raise SystemExit(0 if status=='ok' else 2)
