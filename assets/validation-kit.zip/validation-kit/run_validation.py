"""Reproducible OFFLINE evaluation. Responses are constructed fixtures, NOT GLM outputs."""
import copy
import csv
import hashlib
import json
import tempfile
from datetime import datetime, timezone, timedelta
from pathlib import Path
from quality_rules import QualityService
from rag_service import validate_answer

ROOT = Path(__file__).resolve().parent
results = []
def record(case_id, category, expected, actual, passed, details=''):
    results.append(dict(case_id=case_id, category=category, expected=expected,
                        actual=actual, passed=bool(passed), details=details))
def answer(sources, conflicts=False):
    citation = lambda s: dict(ref=s['ref'], quote=s['excerpt'][:45])
    return dict(dispute='人工构造测试回答：记录存在争议，需要人工核查。',
                distinctions=[dict(text='人工构造：按引用原文核查观察线索。', evidence=[citation(sources[0])])],
                information_needed=[dict(text='人工构造：还需核查原图与实物证据。', evidence=[])],
                review_steps=[dict(text='人工构造：核对适用范围并记录人工结论。', evidence=[citation(sources[0])])],
                conflicts=[dict(text='人工构造：双方约定不同，交负责人确认。', evidence=[citation(sources[0]), citation(sources[1])])] if conflicts else [])

with tempfile.TemporaryDirectory(prefix='qc-rag-eval-') as temp:
    quality = QualityService(ROOT, Path(temp))
    docs = quality.documents()
    assert len(docs) == 50 and all(d['is_demo'] for d in docs)
    for n, doc in enumerate(docs, 1):
        hits = quality.search(f'KEY{n:03}', doc['product'], True, doc['version'], doc['part'])['results']
        good = bool(hits) and all(s['id'] == doc['id'] and s['product'] == doc['product']
                                  and s['part'] == doc['part'] and s['version'] == doc['version'] for s in hits)
        good = good and all(s['excerpt'] in doc['original'] and s['clause_id'] != '未提供'
                            and s['page'] == '未提供' for s in hits)
        record(doc['id'], 'document', '正确检索且出处对应', f'{len(hits)} 条片段', good, doc['source_file'])
    negatives = [
        ('NO-MATCH', 'NO_MATCH_928561', '模拟电视A', True, 'v2.0', '屏幕表面'),
        ('PRODUCT-MISMATCH', 'KEY001', '模拟电视B', True, 'v2.0', '屏幕表面'),
        ('VERSION-MISMATCH', 'KEY001', '模拟电视A', True, 'v9.0', '屏幕表面'),
        ('PART-MISMATCH', 'KEY001', '模拟电视A', True, 'v2.0', '边框'),
        ('ARCHIVED-EXCLUDED', 'KEY005', '模拟电视A', False, '', '屏幕表面')]
    for cid, query, product, history, version, part in negatives:
        found = quality.search(query, product, history, version, part)['results']
        record(cid, 'scope', '0 条匹配', f'{len(found)} 条匹配', not found)
    conflicts = quality.search('清洁复核冲突演示', '模拟电视A', False, 'v2.0', '屏幕表面')
    record('CONFLICT-RETRIEVAL', 'conflict', '列出冲突双方', str(len(conflicts['conflicts'])), bool(conflicts['conflicts']))
    sources = [{**s, 'ref': f'R{i}'} for i, s in enumerate(conflicts['results'], 1)]
    pair = conflicts['conflicts'][0]
    involved = [s for s in sources if (s['id'], s['chunk_id']) in ((pair['left_doc'], pair['left']), (pair['right_doc'], pair['right']))]
    sources = [{**s, 'ref': f'R{i}'} for i, s in enumerate(involved, 1)]
    assert len(sources) == 2
    baseline = answer(sources)
    for cid, payload, pairs in [('VALID-ANSWER', baseline, []), ('VALID-CONFLICT', answer(sources, True), [pair])]:
        try:
            validate_answer(payload, sources, pairs)
            record(cid, 'positive', '接受', '接受', True)
        except ValueError as exc:
            record(cid, 'positive', '接受', str(exc), False)
    invalid = []
    def bad(cid, mutate, category='citation', pairs=None, conflict=False):
        payload = answer(sources, conflict)
        mutate(payload)
        invalid.append((cid, category, payload, pairs or []))
    bad('UNKNOWN-EVIDENCE', lambda a: a['distinctions'][0]['evidence'][0].update(ref='R999'))
    bad('UNKNOWN-INLINE', lambda a: a['review_steps'][0].update(text='人工构造：参照 R999 处理。'))
    bad('FABRICATED-QUOTE', lambda a: a['distinctions'][0]['evidence'][0].update(quote='这句捏造的标准原文并不存在'))
    bad('SHORT-QUOTE', lambda a: a['review_steps'][0]['evidence'][0].update(quote='仅'))
    bad('NO-DISTINCTION-EVIDENCE', lambda a: a['distinctions'][0].update(evidence=[]))
    bad('NO-REVIEW-EVIDENCE', lambda a: a['review_steps'][0].update(evidence=[]))
    bad('INVENTED-PAGE', lambda a: a['review_steps'][0].update(text='人工构造：参照第99页操作。'))
    bad('INVENTED-VERSION', lambda a: a['review_steps'][0].update(text='人工构造：采用 v9.9 标准。'))
    bad('UNKNOWN-INFO-REF', lambda a: a['information_needed'][0].update(evidence=[dict(ref='R999', quote='未知规则编号')]))
    bad('MISSING-CONFLICT', lambda a: a.update(conflicts=[]), pairs=[pair], conflict=True)
    bad('ONE-SIDED-CONFLICT', lambda a: a['conflicts'][0].update(evidence=a['conflicts'][0]['evidence'][:1]), pairs=[pair], conflict=True)
    bad('NO-CONFLICT-EVIDENCE', lambda a: a['conflicts'][0].update(evidence=[]), pairs=[pair], conflict=True)
    bad('MISSING-FIELD', lambda a: a.pop('review_steps'), 'structure')
    bad('EXTRA-FIELD', lambda a: a.update(final_label='合格'), 'structure')
    bad('WRONG-TYPE', lambda a: a.update(information_needed='不是数组'), 'structure')
    bad('EMPTY-DISPUTE', lambda a: a.update(dispute=''), 'structure')
    for cid, category, payload, pairs in invalid:
        try:
            validate_answer(payload, sources, pairs)
            record(cid, category, '拒绝', '被接受', False)
        except ValueError as exc:
            record(cid, category, '拒绝', '拒绝', True, str(exc))
    semantic = copy.deepcopy(baseline)
    semantic['distinctions'][0]['text'] = '人工构造反例：这条样本已确认合格，无需人工复核。'
    try:
        validate_answer(semantic, sources, [])
        record('SEMANTIC-LIMIT', 'boundary', '记录结构校验无法识别该语义错误', '被接受，仍需人工审核', True,
               '合法引用不保证结论受原文支持；此项不得记为拦截成功。')
    except ValueError as exc:
        record('SEMANTIC-LIMIT', 'boundary', '记录实际限制', str(exc), True)

report = dict(generated_at=datetime.now(timezone(timedelta(hours=8))).isoformat(),
              mode='offline_synthetic_fixtures_not_model_outputs', documents=len(docs),
              formats={'txt':25, 'md':25}, document_checks_passed=sum(r['passed'] for r in results if r['category']=='document'),
              citation_cases=12, citation_cases_rejected=sum(r['passed'] for r in results if r['category']=='citation'),
              structure_cases=4, structure_cases_rejected=sum(r['passed'] for r in results if r['category']=='structure'),
              total_checks=len(results), passed=sum(r['passed'] for r in results), results=results,
              real_model_calls_in_this_run=0, user_trials_completed=0, feedback_iterations_completed=0,
              limits=['构造异常响应验证代码，不是50次真实模型效果评测。',
                      '引用编号与摘录校验不能覆盖所有语义幻觉。',
                      '未邀请真实使用者；用户试用与反馈迭代计数均为0。'],
              code_sha256={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in
                           ['quality_rules.py','standard_parser.py','rag_service.py','provider_connection.py']})
(ROOT/'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
with (ROOT/'cases.csv').open('w', encoding='utf-8-sig', newline='') as f:
    writer=csv.DictWriter(f, fieldnames=list(results[0])); writer.writeheader(); writer.writerows(results)
print(json.dumps({k:v for k,v in report.items() if k not in ('results','code_sha256')}, ensure_ascii=True))
assert report['passed'] == report['total_checks']
