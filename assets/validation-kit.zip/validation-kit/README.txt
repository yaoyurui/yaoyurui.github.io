﻿视觉质检助手 · 50份模拟文档与输出校验验证包
所有标准与异常回答均为人工构造的模拟资料，不用于生产判断。
Python 3.10+，在本目录执行：python run_validation.py
只需Python标准库，无需API Key，不调用模型，不读取原工具密钥或数据库。
脚本使用临时目录保存测试数据库，运行后清理；生成report.json及cases.csv。
报告中12项引用/出处异常和4项结构异常属于构造响应校验，不是模型幻觉发生次数。
50份文档为25份TXT和25份Markdown，覆盖5种模拟产品、2种部位、5种缺陷主题。
线上原有30条模拟样本与本验证库50份文档属于不同数据集，不能合并或互相替代。
源码来自现有工具的quality_rules.py、standard_parser.py、rag_service.py、provider_connection.py，哈希记录在report.json。
真实用户试用和根据反馈迭代尚未完成。
